/**
 * @namespace vtron.comp.std.map
 */
$.namespace("vtron.comp.std.map");
/**
 * v-std-map-cesium地图组件
 * @module vtron.comp.std.map
 * @class vtron.comp.std.map.Cesium
 */
vtron.comp.std.map.Cesium = Polymer({
    is: "v-std-map-cesium",
    behaviors: [
        vtron.comp.behavior.SizeBehavior,
        vtron.comp.behavior.PositionBehavior,
        vtron.comp.behavior.StdLifecycleBehavior, //标准组件的生命周期扩展行为
    ],
    properties: {
        /**
         * 是否自动加载地图
         * @property autoload
         * @type String
         */
        autoload: {
            type: String,
            value: "true",
            reflectToAttribute: true
        },
        /**
         * 样式数据URL（丢弃）
         * @property styleUrl
         * @type String
         */
        styleUrl: {
            type: String,
            reflectToAttribute: true
        },
        /**
         * 图层数据URL
         * @property layerUrl
         * @type String
         */
        layerUrl: {
            type: String,
            reflectToAttribute: true
        },

        /**
        /**
         * 搜索图层集合
         */
        searchLayerArray: {
            type: Array,
            value: [],
            reflectToAttribute: true
        },

        /**
         * 地图底图URL
         * @property mapUrl
         * @type String
         */
        mapUrl: {
            type: String,
            reflectToAttribute: true
        },

        /**
         * 地图底图类型
         * @property mapType
         * @type String
         */
        mapType: {
            type: String,
            value: "WebMapServiceImageryProvider",
            reflectToAttribute: true
        },

        /**
         * WMS图层
         * @property wmsLayers
         * @type String
         */
        wmsLayers: {
            type: String,
            reflectToAttribute: true
        },

        /**
         * 地图底图图片格式
         * @property format
         * @type String
         */
        format: {
            type: String,
            value: "png",
            reflectToAttribute: true
        },

        /**
         * 地图中心点X
         * @property cenX
         * @type Number
         */
        cenX: {
            type: Number,
            value: 0,
            reflectToAttribute: true
        },

        /**
         * 地图中心点Y
         * @property cenY
         * @type Number
         */
        cenY: {
            type: Number,
            value: 0,
            reflectToAttribute: true
        },

        /**
         * 地图默认层级
         * @property level
         * @type Number
         */
        level: {
            type: Number,
            value: 10,
            reflectToAttribute: true
        },

        /**
         * 地图最小层级
         * @property minLevel
         * @type Number
         */
        minLevel: {
            type: Number,
            value: 1,
            reflectToAttribute: true
        },

        /**
         * 地图最大层级
         * @property maxLevel
         * @type Number
         */
        maxLevel: {
            type: Number,
            value: 20,
            reflectToAttribute: true
        },

        /**
         * 地理格式
         * @property mapScheme
         * @type String
         */
        mapScheme: {
            type: String,
            value: "GeographicTilingScheme",
            reflectToAttribute: true
        },

        /**
         * 边界：西
         * @property west
         * @type Number
         */
        west: {
            type: Number,
            value: -180,
            reflectToAttribute: true
        },

        /**
         * 边界：南
         * @property south
         * @type Number
         */
        south: {
            type: Number,
            value: -90,
            reflectToAttribute: true
        },

        /**
         * 边界：东
         * @property east
         * @type Number
         */
        east: {
            type: Number,
            value: 180,
            reflectToAttribute: true
        },

        /**
         * 边界：北
         * @property north
         * @type Number
         */
        north: {
            type: Number,
            value: 90,
            reflectToAttribute: true
        },

        /**
         * 地图倾斜角度
         * 90度为俯视图
         */
        pitch: {
            type: Number,
            value: 45,
            reflectToAttribute: true
        },

        /**
         * 地图缺省颜色
         */
        baseColor: {
            type: String,
            value: 'rgba(0, 0, 128, 1.0)',
            reflectToAttribute: true
        },

        /**
         * 图标放大倍数
         */
        imageScaleFactor: {
            type: Number,
            value: 1,
            reflectToAttribute: true
        },

        /**
         * 地图反色
         */
        invertFlag: {
            type: Boolean,
            value: false,
            reflectToAttribute: true
        },

        /**
         * 绘线的颜色，目前只作用于线选
         */
        lineColor: {
            type: String,
            value: 'rgba(255, 0, 0, 0.8)',
            reflectToAttribute: true
        },

        /**
         * 绘线的宽度，目前只作用于线选
         */
        lineWidth: {
            type: Number,
            value: 200,
            reflectToAttribute: true
        },

        /**
         * 绘圆的颜色，目前只作用于圈选
         */
        circleColor: {
            type: String,
            value: 'rgba(255, 0, 0, 0.8)',
            reflectToAttribute: true
        },

        /**
         * 多边形面的颜色，目前只作用于面选
         */
        polygonColor: {
            type: String,
            value: 'rgba(255, 0, 0, 1)',
            reflectToAttribute: true
        },
        /**
         * 瓦片层级参数
         */
        maximumScreenSpaceError: {
        	type: Number,
            value: 4,
            reflectToAttribute: true
        },
        /**
         * 默认相机参数,"x:,y:,z:,heading:,pitch:,roll:"
         * @property x y z 世界坐标
         * @type Number
         */
        defaultCamera: {
            type: String,
            value: null,
            reflectToAttribute: true
        },
    },

    created: function() {
        this._viewer = null; //内部CesiumViewer对象
    },

    attached: function() {
        if (this.autoload == "true") {
            this.init();
        }
    },

    detached: function() {
        if(this._viewer){
            this._viewer.destroy();
        }
    },

    init: function() {
        var dom = this.$$("#cesiumContainer");
        //if ($(this).is(":hidden")) return; //如果组件本身是隐藏状态，则不渲染
        $(dom).empty();
        this.canvasWidth = dom.offsetWidth;
        this.canvasHeight = dom.offsetHeight;
        this._dsLayer = this.$.dsLayer;
        this._dsLayer.url = this.layerUrl;
        this._init(dom);
        // 初始化完成
        this.loaded = true;
    },

    _init: function(dom) {
        var defaultImageryProvider = this._createImageryProvider({
            mapType: this.mapType,
            mapUrl: this.mapUrl,
            wmsLayers: this.wmsLayers,
            format: this.format,
            minimumLevel: this.minLevel,
            maximumLevel: this.maxLevel,
            mapScheme: this.mapScheme,
            west: this.west,
            south: this.south,
            east: this.east,
            north: this.north,
            mapName:'defaultBaseMap',
            invertValue: this.baseTileInvertType
        });
        defaultImageryProvider.name = 'defaultBaseMap';
        //defaultImageryProvider.invertValue=
        defaultImageryProvider.show=true;
        this._defaultImageryTile = defaultImageryProvider;

        var mapProjection = new Cesium.GeographicProjection();
        var globe = new Cesium.Globe(mapProjection.ellipsoid);
        globe.tileCacheSize = 8000;        //瓦片缓存数量
        globe.maximumScreenSpaceError  = this.maximumScreenSpaceError || 4;
        
        // 设置默认选项
        var defaultOption = {
            imageryProvider: defaultImageryProvider,
            animation: false,
            baseLayerPicker: false,
            fullscreenButton: false,
            geocoder: false,
            homeButton: false,
            infoBox: false,
            shouldAnimate: true,
            //scene3DOnly: true,//chkun
            sceneModePicker: false,
            selectionIndicator: false,//chkun test
            timeline: false,
            navigationHelpButton: false,
            navigationInstructionsInitiallyVisible: false,
            globe: globe,
            contextOptions: {
                webgl: {
                    antialias: false,
                    alpha: false
                }
            },
        };

        //内部CesiumViewer对象
        this._viewer = new Cesium.Viewer(dom, defaultOption);
        this._viewer.scene.moon.show = false;
        // 地球默认瓦片颜色
        // this._viewer.scene.globe.depthTestAgainstTerrain = true;
        this._viewer.scene.globe.baseColor = Cesium.Color.fromCssColorString(this.baseColor);
        // 重新设置相机修改的阈值
        this._viewer.camera.percentageChanged = 0.01;
        this.initSceneResource();
        this.moveReset();
        this.initEvent();
    },

    /**
     * 创建ImageryProvider
     */
    _createImageryProvider: function(config) {
        var imageryProvider = null;
        if (config.mapType == "WebMapServiceImageryProvider") {
            var options = {
                url: config.mapUrl,
                layers: config.wmsLayers,
                parameters: {
                    "format": "image/" + config.format
                },
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            imageryProvider = new Cesium.WebMapServiceImageryProvider(options);

        } else if (config.mapType == "UrlTemplateImageryProvider") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            imageryProvider = new Cesium.UrlTemplateImageryProvider(options);

        } else if (config.mapType == "ArcGisMapServerImageryProvider") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            imageryProvider = new Cesium.ArcGisMapServerImageryProvider(options);

        } else if (config.mapType == "PGISImageryProvider_V10") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            options.online = (config.online == "true");
            options.format = config.format || "tiles";
            options.layer = config.layer || "layer0";
            options.tileMatrixSetID = config.layer || "layer0";
            imageryProvider = new PGISImageryProvider_V10(options);

        } else if (config.mapType == "PGISImageryProvider_V03") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            options.online = (config.online == "true");
            options.format = config.format || "png";
            imageryProvider = new PGISImageryProvider_V03(options);

        } else if (config.mapType == "PGISImageryProvider_V03_local") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            options.online = (config.online == "true");
            options.format = config.format || "png";
            imageryProvider = new PGISImageryProvider_V03_local(options);

        } else if (config.mapType == "TileMapServiceImageryProvider") {
            var options = {
                url: config.mapUrl,
            };
            options.tilingScheme = this._createTilingScheme(config);
            options.minimumLevel = parseInt(config.minimumLevel) || 1;
            options.maximumLevel = parseInt(config.maximumLevel) || 20;
            imageryProvider = Cesium.createTileMapServiceImageryProvider(options);

        }

        return imageryProvider;
    },

    /**
     * 设置tilingScheme属性
     */
    _createTilingScheme: function(config) {
        var tilingScheme = null;
        if (config.mapScheme == "GeographicTilingScheme") {
            tilingScheme = new Cesium.GeographicTilingScheme();
        }
        if (config.mapScheme == "WebMercatorTilingScheme") {
            tilingScheme = new Cesium.WebMercatorTilingScheme();
        }
        var west = parseFloat(config.west);
        var south = parseFloat(config.south);
        var east = parseFloat(config.east);
        var north = parseFloat(config.north);
        if (west && south && east && north) {
            tilingScheme.rectangleToNativeRectangle(new Cesium.Rectangle(west, south, east, north));
        }
        return tilingScheme;
    },
});

/**
 * 地球鼠标事件，以及一些列内部属性的初始化
 */
vtron.comp.std.map.Cesium.prototype.initEvent = function() {
    if(!this._viewer) return;
    this.fire('map-loaded', '');

    //设置鼠标的操作
    this._viewer.scene.screenSpaceCameraController.zoomEventTypes = [Cesium.CameraEventType.WHEEL, Cesium.CameraEventType.PINCH];
    this._viewer.scene.screenSpaceCameraController.tiltEventTypes = [Cesium.CameraEventType.PINCH, Cesium.CameraEventType.RIGHT_DRAG];
    
    //鼠标图片资源:
    if(this.custom_Cursor==undefined){
        this.custom_Cursor = [];
        if(this.offsetWidth<4096&&this.offsetHeight<4096){
            //this.custom_Cursor['move']=this.addCursorStyle("image/cursor/pc_cursor/move.png",1,8,8,false);//左键平移
            this.custom_Cursor['move']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/move.png",1,10,10,false);//左键平移
            this.custom_Cursor['move-drag']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/move-drag.png",1,10,10,false);//左键平移
            this.custom_Cursor['point']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/point.png",1,0,0,false);
            this.custom_Cursor['draw-line']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/draw-line.png",1,0,0,false);//绘笔
            this.custom_Cursor['choose-line']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/choose-line.png",1,0,0,false);//线选
            this.custom_Cursor['choose-polygon']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/choose-polygon.png",1,0,0,false);//面选
            this.custom_Cursor['choose-circle']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/choose-circle.png",1,0,0,false);//圈选
            this.custom_Cursor['choose-rectangle']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/choose-rectangle.png",1,0,0,false);//四边形选择
            this.custom_Cursor['tilt']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/pc_cursor/tilt.png",1,0,0,false); //倾斜和旋转
        }
        else{
            this.custom_Cursor['move']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/move.png",1,32,32,false);
            this.custom_Cursor['move-drag']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/move-drag.png",1,32,32,false);
            this.custom_Cursor['point']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/point.png",1,0,0,false);
            this.custom_Cursor['draw']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/draw.png",1,0,0,false);
            this.custom_Cursor['tilt']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/tilt.png",1,0,0,false); 
            this.custom_Cursor['choose-line']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/choose-line.png",1,0,0,false);
            this.custom_Cursor['choose-polygon']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/choose-polygon.png",1,0,0,false);
            this.custom_Cursor['choose-circle']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/choose-circle.png",1,0,0,false);
            this.custom_Cursor['choose-rectangle']=this.addCursorStyle("/comp-base/std-map/v-std-map-cesium/images/cursor/wall_cursor/choose-rectangle.png",1,0,0,false);
        }
    }

    //属性初始化
    this._mousex = -1;//鼠标当前位置
    this._mousey = -1;
    this._premousex = -1;//鼠标的上一次位置
    this._premousey = -1;

    this.useMousePickEntities=true;//默认开启鼠标移动到要素时的提示信息功能

    //this._imageryTiles=[];//记录底图的信息[{'name':,'visible':,'invertType':}]
    //this._imageryTiles = this._imageryTiles || {};
    //this._imageryTiles[this._defaultImageryTile.name]=this._defaultImageryTile;

    this.mapApngMaterial = new Map();//<apngurl,canvas>
    //apng
    /*var purl = '/app-gongan/images/map/emergency.png';
    var canvasobj = this.mapApngMaterial.get(purl);
    if(!canvasobj){
        canvasobj = document.createElement('canvas');
        var instance = this;
        testpromise(this._viewer,purl,canvasobj).then(function(canvas){
            instance.mapApngMaterial.set(purl,canvasobj);
            var material = new Cesium.ImageMaterialProperty({
                            image: canvasobj,
                            // repeat: new Cesium.Cartesian23(0.5, 0.5),
                            transparent: true
                        });
            canvasobj.material = material;
            
            //test:提前把apng加到一个实体中，后续再用该材质，则能加快速度。
            var apngpolygon = instance._viewer.entities.add({
                    id:'test',               
                    polygon : {
                        hierarchy : {
                             positions : Cesium.Cartesian3.fromDegreesArray([0,90,
                                                                0.01,90,
                                                                0.01,89,
                                                                0,89])
                        },
                        material:new Cesium.ImageMaterialProperty({
                            image:canvas, 
                            transparent:true
                        }),
                    },
            });
            apngpolygon.show = false;
        });  
    }*/
    //apng

    this.pathTracking_startTime = undefined;//轨迹回放的开始时间，该变量用来控制重播
    
    //点图层在相机低于20000米时显示
    //如果要给某些图层设置在某个高度范围内显示，则需要新加接口，后续补充完善
    //this._pointLayer_default_distanceDisplayCondition = 200000;
    //this._pointLayer = new Map();//记录点图层对象，方便控制点图层随高度变化的显隐

    //记录图层的最大最小显示高度
    this._layerDefaultDisplayCondition = 200000;
    this._layerDisplayCondition = new Map();//记录图层对象，方便控制点图层随高度变化的显隐

    //记录包含动态点的图层，避免每次更新都遍历datasourcecollection
    //例如：实时GPS：添加一个点，改变点的位置模拟gps，本质是点图层
    this._dynameLayer_dataSource=[];

    //轨迹图层：本质是线图层
    //历史gps轨迹：添加一个路径，让点沿路径运动
    this._pathTrackingLayer_dataSource=[];

    // 设置当前状态为 'choose-polygon-lineine|draw-line|choose-circle|choose-polygon|move|draw'
    this.changeState('move');
    // 双击选中模型
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        // 判断操作状态:绘线
        switch(this.optState) {
            case 'choose-circle':
               //若没有绘制圆直接双击，则转换为默认点选双击
				if( this.optRadius<=0){
					//删除该圆
					this.optChooseResult = false;
					// 默认双击选中节点
					pointDoubleClick(this,event.position);
				}
				else{
					 // 圆绘制结束后的空间分析
					var result = this.searchByTurf(this.searchLayerArray, this.optID, this.optState, this.optVertices, this.lineWidth, this.optRadius,{},false);
					//chkun 如果结果为空则清除cirlce
					if(result.searchResultisNull == false){
						this.fire('drawCircle', {'optState': 'drawCircle', 
							'optID': this.optID, 
							'vertices': this.optVertices, 
							'radius': this.optRadius,
							'circleColor':  this.circleColor
						});
						this.optChooseResult = true;

                        //this.fire('elementRangeSelect', result);
					}
					else{
						//如果结果为空，则删除该圆
						//this.layerDelete(this.optState,this.optID);
						this.optChooseResult = false;
					}
				}
				this.changeState(this.optState);
                break;
            case 'choose-line':
            case 'choose-polygon':
				//小于等于两个点，构不成面，则转换为默认点选双击
				if(this.optVertices.length<=2){
					//删除该面
					this.optChooseResult = false;
					// 默认双击选中节点
					pointDoubleClick(this,event.position);
				}
				else{
					var result = this.searchByTurf(this.searchLayerArray, this.optID, this.optState, this.optVertices, this.lineWidth,0,{},false);
					if(result.searchResultisNull == false){
						this.optChooseResult = true;
					}
					else{
						this.optChooseResult = false;
					}
				}
                this.changeState(this.optState);
            case 'draw-line':
                // this.fire('draw-point', {'optState': this.optState, 
                //     'optID': this.optID, 
                //     'points': this.optVertices, 
                //     'width': this.lineWidth, 
                //     'rgb': this.lineColor
                // });
                // break;
            case 'draw':
                this.fire('draw-point', {'optState': this.optState, 
                    'optID': this.optID, 
                    'points': this.optVertices, 
                    'width': this.lineWidth, 
                    'rgb': this.lineColor
                });
                this.changeState(this.optState);
                break;
            default:
                // 默认双击选中节点
				pointDoubleClick(this,event.position);
        }
    }, Cesium.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
	
    //默认点选双击  zhanggang
    var pointDoubleClick = function(myThis,position){
                var pickObject = myThis._viewer.scene.pick(position);
                if(Cesium.defined(pickObject)) {
                    var entity = pickObject.id;
                    if(entity) {
                        var data = {
                            id: entity.id,
                            x: entity.x,
                            y: entity.y,
                            info: entity.otherProperty,
                            layerName: entity.name
                        }
                        myThis.fire("mapLayerClick", data);
                    }
                }
    };
	// 左键单击
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        // 判断操作状态:绘线
        switch(this.optState) {
            case 'choose-line':
            case 'draw-line':
                var position = this._viewer.camera.pickEllipsoid(event.position);
                this.optVertices.push(position); 
                this.addLineElement(this.optState, this.optID, this.optVertices, this.lineWidth, this.lineColor);
                this._viewer.scene.requestRender();
                break;
            case 'choose-polygon':
                var position = this._viewer.camera.pickEllipsoid(event.position);
                this.optVertices.push(position);
                this.addPolygonElement(this.optState, this.optID, this.optVertices, this.polygonColor);
                this._viewer.scene.requestRender();
                break;
            case 'choose-circle':
                // 首先判断圈的ID是否存在
                var circle = this.getEntityById(this.optState, this.optID);
                if(circle) break;
                var position = this._viewer.camera.pickEllipsoid(event.position);
                this.optVertices.push(position);
                this.addCircleElement(this.optState, this.optID, position, 1, this.circleColor);
                this._viewer.scene.requestRender();
                break;
            case 'draw':
                var position = this._viewer.camera.pickEllipsoid(event.position);
                this.optVertices.push(position);
                this.addLineElement(this.optState, this.optID, this.optVertices, this.lineWidth, this.lineColor);
                break;
        }
        if(event) {
            let position = this._viewer.camera.pickEllipsoid(event.position);
            if(position) {
                let geoCoord = this.getCartographicFromCartesian(position.x, position.y, position.z);
                let detail = {
                    type: 'left',
                    x: geoCoord.lon,
                    y: geoCoord.lat
                };
                this.fire('mouse-click', detail);
                this.fire('click-position', detail);
            }
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    // 鼠标左键按下
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        this._mousetype ='LEFT_DOWN';
        //this.changeCursor("move");//修改为平移地图的鼠标样式
        switch(this.optState) {
            // case 'draw':
            //     var position = this._viewer.camera.pickEllipsoid(event.position);
            //     this.optVertices.push(position);
            //     this.addLineElement(this.optState, this.optID, this.optVertices, this.lineWidth, this.lineColor);
            //     break;
            case 'move':
                this.changeCursor("move-drag");//修改为旋转地图的鼠标样式
            default:
                this.changeCursor("move-drag");
        }
    }, Cesium.ScreenSpaceEventType.LEFT_DOWN);
    // 鼠标弹起
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        this._mousetype ='LEFT_UP';
        //this.changeCursor(this.optState);//恢复光标样式
        switch(this.optState) {
            // case 'draw':
            //     this.changeState(this.optState);
            //     break;
            case 'move':
                this.changeCursor("move");//修改为旋转地图的鼠标样式
            default:
                this.changeCursor(this.optState);
        }
    }, Cesium.ScreenSpaceEventType.LEFT_UP);
    // 右键单击
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        event.type = 'right';
        this._mousetype ='RIGHT_CLICK';
        //this.changeCursor("tilt");//修改为旋转地图的鼠标样式
        this.fire('mouse-click', event);
    }, Cesium.ScreenSpaceEventType.RIGHT_CLICK);
    
    //右键按下
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        event.type = 'RIGHT_DOWN';
        this._mousetype ='RIGHT_DOWN';
        this.changeCursor("tilt");//修改为旋转地图的鼠标样式
        this.fire('right-down', event);
    }, Cesium.ScreenSpaceEventType.RIGHT_DOWN);

    //右键弹起
    this._viewer.screenSpaceEventHandler.setInputAction((event) =>{
        event.type = 'RIGHT_UP';
        this._mousetype ='RIGHT_UP';
        this.changeCursor(this.optState);//恢复光标样式
        //取消当前选择绘制的图形:
        if(this._mousetype2 != 'RIGHT_DOWN+MOUSE_MOVE'){
            this.deleteTmpChooseGeomtry();
        }
        this.fire('right-up', event);
    }, Cesium.ScreenSpaceEventType.RIGHT_UP);
    
    //MIDDLE事件
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        event.type = 'MIDDLE';
        this._mousetype ='MIDDLE';
        this.fire('middle', event);
    }, Cesium.ScreenSpaceEventType.MIDDLE_DOWN);

    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        event.type = 'MIDDLE-UP';
        this._mousetype ='MIDDLE-UP';
        this.fire('middleUp', event);
    }, Cesium.ScreenSpaceEventType.MIDDLE_UP);

    //wheel事件 //滚轮缩放
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        var retValue = {};
        retValue.type = 'WHEEL';
        retValue.value = event;
        this._mousetype ='WHEEL';
        this.fire('WHEEL', retValue);
    }, Cesium.ScreenSpaceEventType.WHEEL);

    // 鼠标移动事件
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        //this._mousetype = 'MOUSE_MOVE';//不能设置鼠标平移！！！！！
        this._premousex = this._mousex;
        this._premousey = this._mousey;
        this._mousex = event.endPosition.x;
        this._mousey = event.endPosition.y;
        
        //this._mousetype记录鼠标按键信息（不包含mousemove）
        //this._mousetype2记录mousetype+mousemove，比如按鼠标左键并移动鼠标等等
        this._mousetype2 = this._mousetype + '+MOUSE_MOVE';
        
        //当前鼠标点的地理坐标
        var position = this._viewer.camera.pickEllipsoid(event.endPosition);
        
        switch(this.optState) {
            case 'choose-line':
            case 'draw-line':
                // 绘制一截临时线段
                if(this.optVertices.length) {
                    if(position)
                    {
                        var tempLineVertices = this.optVertices.concat(position);
                        this.addLineElement(this.optState, this.optID, tempLineVertices);
                    }
                }
                break;
            case 'draw':
                if(this.optVertices.length) {
                    //var position = this._viewer.camera.pickEllipsoid(event.endPosition);
                    if(position){
                        this.optVertices.push(position);
                        this.addLineElement(this.optState, this.optID, this.optVertices);
                    }
                }
                break;
            case 'choose-polygon':
                // 绘制一截临时线段
                if(this.optVertices.length) {
                    //var position = this._viewer.camera.pickEllipsoid(event.endPosition);
                    if(position){
                        var tempPolygonVertices = this.optVertices.concat(position);
                        if(tempPolygonVertices.length == 2) {
                            this.addLineElement("choose-polygon-line", this.optID, tempPolygonVertices, this.lineWidth * 0.2, this.polygonColor);
                        } else {
                            this.layerDelete("choose-polygon-line", this.optID);   
                        }
                        this.addPolygonElement(this.optState, this.optID, tempPolygonVertices);
                    }
                }
                break;
            case 'choose-circle':
                if(this.optVertices.length) {
                    //var position = this._viewer.camera.pickEllipsoid(event.endPosition);
                    if(position){
                        var radius = Math.max(Cesium.Cartesian3.distance(this.optVertices[0], position), 0);
                        this.optRadius = radius;
                        this.addCircleElement(this.optState, this.optID, this.optVertices[0], radius);   
                    }
                }  
                break;
            default:
                if(this.canvasWidth==0){
                    this.canvasWidth = this.offsetWidth;
                    this.canvasHeight = this.offsetHeight;
                }
                if((event.endPosition.x<0||event.endPosition.y<0)||(event.endPosition.x>this.canvasWidth||event.endPosition.y>this.canvasHeight)){
                    this.enableMap(false);
                } 
                else{
                    this.enableMap(true);
                }
                //console.log('move');
                var detail = {};
                detail.position = this._viewer.camera.position;
                detail.heading = this._viewer.camera.heading;
                detail.pitch = this._viewer.camera.pitch;
                detail.roll = this._viewer.camera.roll;
                detail.geoCoord = this.getCartographicFromCartesian(detail.position.x, detail.position.y, detail.position.z); 
                detail.pithDegree = Cesium.Math.toDegrees(detail.pitch);
                detail.positionCartographic = this._viewer.camera.positionCartographic;
                if(this._mousetype=="LEFT_DOWN"||this._mousetype=="RIGHT_DOWN"||this._mousetype =='MIDDLE'){
                    //this._mousetype = 'MOUSE_MOVE';//平移和旋转地图
                    this.fire("movemap", detail, {bubbles: false}); //鼠标按键+平移=移动地图
                }
                else{
                    this.fire("move", detail, {bubbles: false});
                }

                //在非choose和draw状态下，进行pick
                //if(this.UseMousePickEntities)
                    //_doPickedJob(this);   
        }
		//进行pick
		if(this.useMousePickEntities)
		_doPickedJob(this);
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

    //ctrol+move事件
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        this._mousetype = 'CTRL+MOUSE_MOVE';
        this._mousex = event.endPosition.x;
        this._mousey = event.endPosition.y;
        if((this._mousex<0||this._mousey.y<0)||(this._mousex>this.canvasWidth||this._mousey>this.canvasHeight)){
            this.enableMap(false);
        } 
        else{
            this.enableMap(true);
        }
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE,Cesium.KeyboardEventModifier.CTRL);

    //shift+move事件
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        this._mousetype = 'SHIFT+MOUSE_MOVE';
        this._mousex = event.endPosition.x;
        this._mousey = event.endPosition.y;
        if((this._mousex<0||this._mousey.y<0)||(this._mousex>this.canvasWidth||this._mousey>this.canvasHeight)){
            this.enableMap(false);
        } 
        else{
            this.enableMap(true);
        }  
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE,Cesium.KeyboardEventModifier.SHIFT);

    //alt+move事件 
    this._viewer.screenSpaceEventHandler.setInputAction((event) => {
        this._mousetype = 'ALT+MOUSE_MOVE';
        this._mousex = event.endPosition.x;
        this._mousey = event.endPosition.y;
        if((this._mousex<0||this._mousey.y<0)||(this._mousex>this.canvasWidth||this._mousey>this.canvasHeight)){
            this.enableMap(false);
        } 
        else{
            this.enableMap(true);
        }   
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE,Cesium.KeyboardEventModifier.ALT);

    // 监听相机移动的事件,比如定位。地图显示范围发生改变，则会进入该函数。
    // 相机改变会外抛相机相关参数，以及 detail.info， detail.info=‘mousemove’表示由于直接使用鼠标操作地图引发的变化
    // 反之，是由于调用接口指令引发的。
    var doCameraChangedEvent = function(instance ){
        let detail = {};
            detail.position = instance._viewer.camera.position;
            detail.heading = instance._viewer.camera.heading;
            detail.pitch = instance._viewer.camera.pitch;
            detail.roll = instance._viewer.camera.roll;
            detail.geoCoord = instance.getCartographicFromCartesian(detail.position.x, detail.position.y, detail.position.z); 
            detail.pithDegree = Cesium.Math.toDegrees(detail.pitch);
            detail.positionCartographic = instance._viewer.camera.positionCartographic;
            detail.info=instance._cmdinfo||"";

            if((instance.optState == 'move' && instance._mousetype=='MOUSE_MOVE' )
                ||instance._mousetype=='WHEEL'
                ||instance._mousetype=="CTRL+MOUSE_MOVE"
                ||instance._mousetype=="SHIFT+MOUSE_MOVE"
                ||instance._mousetype=="ALT+MOUSE_MOVE"
                ||instance._mousetype2=="RIGHT_DOWN+MOUSE_MOVE"
                ||instance._mousetype2=="LEFT_DOWN+MOUSE_MOVE"
                ){
                detail.info="mousemove";
                instance._cmdinfo="";

                //如果当前是鼠标滚轮触发的地图缩放，则每次滚轮操作后都恢复mousetype变量
                if(instance._mousetype=='WHEEL') 
                    instance._mousetype='move';
            }
        
        //每次相机变化，都记录
        instance._viewer.precamera = instance._viewer.camera;
        
        var heading = instance._viewer.camera.heading;
        instance._viewer.compassangle = 360-Cesium.Math.toDegrees(heading);
        detail.compassangle = instance._viewer.compassangle;
            
        instance.fire("camera-change", detail, {bubbles: false}); 

        instance._viewer.camera.cmdormouse="";
    };

    this._viewer.camera.changed.addEventListener(() => {
        //console.log("camera changed"); 
        doCameraChangedEvent(this);
    });

    this._viewer.scene.postRender.addEventListener(function(){
        if(this._viewer){
           console.log("postRender");  
        }  
    }); 

    // 键盘空格恢复默认视角
    document.addEventListener('keydown', (e) => {
        switch(e.keyCode) {
            case 32: 
                this.moveReset();
                break;
            default:
        }
    });

    //相机移动结束事件
    this._viewer.scene.camera.moveEnd.addEventListener(()=>{
        doCameraChangedEvent(this);

        //控制点图层的显隐
        var curcameraHeight = this._viewer.camera.positionCartographic.height;
        var instance = this;
        /*if(curcameraHeight > this._pointLayer_default_distanceDisplayCondition && this._pointLayer.size>0){
            this._pointLayer.forEach(function(value,key,map){
                //value是应用开发设置的图层显隐，
                if(value == true){
                    var layer = instance.getDataSourceByName(key);
                    if(layer.show == true)
                         layer.show = false;
                }                
            })      
        }
        else
        {
            this._pointLayer.forEach(function(value,key,map){
                if(value == true){
                    var layer = instance.getDataSourceByName(key);
                    if(layer.show == false)
                          layer.show = true;
                }
                
            })
        }*/

        //设置图层的显隐
        //遍历this._layerDisplayCondition容器，获取到图层的最大最小显示高度范围
        //如果当前高度在范围内，则该图层显示，否则图层隐藏
        this._layerDisplayCondition.forEach(function(value,key,map){
            var layer = instance.getDataSourceByName(key);
            if(layer){
                var oldshow = layer.show;
                if(curcameraHeight>=value.minDisplayAltitude&&curcameraHeight<=value.maxDisplayAltitude){
                    if(value.visible!=false)
                        layer.show = true;
                }
                else{
                    layer.show = false;
                }
                if(oldshow!=layer.show){
                    instance.fire("layer-show", {"layerName": key, show: layer.show}, {bubbles: false});                
                }
            }
        })
    });

    //时间动画事件
    this._viewer.clock.onTick.addEventListener((clock) => {
        return;
        //获取轨迹图层
        //轨迹图层中动态线的position更新
        for(var layerObject =0;layerObject<this._pathTrackingLayer_dataSource.length;layerObject++){
            var pathTrackingLayer = this._pathTrackingLayer_dataSource[layerObject];
            for(var i=0;i<pathTrackingLayer.entities._entities.length;i++)
            {
                var entity = pathTrackingLayer.entities.values[i];
                if(!entity.position) return;
                var position = entity.position.getValue(clock.currentTime);
                if(Cesium.JulianDate.compare(clock.currentTime, this._viewer.clock.stopTime)<0){
                    entity.dyPositions.push(position);
                }
            }
        }
    });
};

/**
 * 初始化场景数据: 如添加静态图层数据
 */
vtron.comp.std.map.Cesium.prototype.initSceneResource = function() {
    this._dsLayer.load({
        success: (data) => {
            if(data.data && !data.data.length) return;
            data.data.forEach((item) => {
                var bShowLayer = item.hidden ? false : true;
                switch(item.layerType) {
                    case 'point':
                        this.loadPointLayerGeoJsonData(item.layerName, item.url, item.imageUrl, item.scale, item.height, bShowLayer, item.supportSearch);
                        break;
                    case 'line':
                        this.loadPolylineLayerGeoJsonData(item.layerName, item.url, item.width, item.color, item.glowPower, item.distanceDisplay, bShowLayer);
                        break;
                    case 'polygon':
                        this.loadPolygonLayerGeoJsonData(item.layerName, item.url, item.imageUrl, bShowLayer);
                    default:
                }
            });
        }
    })
};

/**
 * 添加瓦片底图
 */
vtron.comp.std.map.Cesium.prototype.loadImageryTile = function(name, tileInfo, show = true) {
    this._imageryTiles = this._imageryTiles || {};
    var config = {
        mapType: tileInfo.mapType || tileInfo["map-type"],
        mapUrl: tileInfo.mapUrl || tileInfo["map-url"],
        wmsLayers: tileInfo.wmsLayers || tileInfo["wms-layers"],
        format: tileInfo.format,
        minimumLevel: tileInfo.minLevel || tileInfo["min-level"],
        maximumLevel: tileInfo.maxLevel || tileInfo["max-level"],
        mapScheme: tileInfo.mapScheme || tileInfo["map-scheme"],
        west: tileInfo.west,
        south: tileInfo.south,
        east: tileInfo.east,
        north: tileInfo.north,
    }
    var provider = this._createImageryProvider(config);

    var layers = this._viewer.scene.imageryLayers;
    var tile = layers.addImageryProvider(provider);
    tile.invertValue=tileInfo.invertType || tileInfo["invert-type"]||0;//需要反色的值
    this._imageryTiles[name] = tile;
    tile.show = show;
}

/**
 * 瓦片底图显示/隐藏
 */
vtron.comp.std.map.Cesium.prototype.imageryTileShow = function(name, show = true) {
    this._imageryTiles = this._imageryTiles || {};
    var tile = this._imageryTiles[name];
    if(tile){
        tile.show = show;
    }
}

/**
 * 获取所有瓦片底图的info
 * retValue:
 * [
 *   {name:地图名，invertValue：反色值，show：是否显示}
 * ]
 */
vtron.comp.std.map.Cesium.prototype.imageryTileInfo = function(){//imageryTileNames
    this._imageryTiles = this._imageryTiles || {};
    var names = [];
    //names.push({'name':this._defaultImageryTile.name,'invertValue':this._defaultImageryTile.invertValue,'show':this._defaultImageryTile.show});
    for(var name in this._imageryTiles){
        var info = {};
        info.name=name;
        info.invertValue=this._imageryTiles[name].invertValue;
        info.show = this._imageryTiles[name].show;
        names.push(info);
    }
    return names;
}

/**
 * 添加静态点图层数据，数据源是GeoJson格式，其中参数name是选中节点后判断类型的依据
 * layerName：alert|gps|yiyuan, bShowLayer: 默认显示加载层
 */
vtron.comp.std.map.Cesium.prototype.loadPointLayerGeoJsonData = function(layerName, url, imageUrl, scale = 1, height = 10, bShowLayer = true, supportSearch = false) {
    this._dsLayer.url = url;
    supportSearch && this.searchLayerArray.push(layerName);
    var instance = this;
    this._dsLayer.load({
        success: (data) => {
            if(data.data && !data.data.length) return;
            var entitiesCollection = new Cesium.CustomDataSource(layerName);
            entitiesCollection.imageSrc = imageUrl;
            for(var i = 0, len = data.features.length; i < len; i++) {
                let id = data.features[i].id,
                    coord = data.features[i].geometry.coordinates,
                    properties = data.features[i].properties,
                    position = Cesium.Cartesian3.fromDegrees(coord[0], coord[1], height),
                    entity = entitiesCollection.entities.add({
                        id: id,
                        name: layerName,
                        position: position,
                        billboard: {
                            image : imageUrl,
                            scale: this.imageScaleFactor * scale,
                            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                            //sizeInMeters : true,
                            scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                            //distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0.0, 100000),
                        }
                    });
                //entity.show = bShowLayer;
                entity.layerName = layerName;
                entity.x = coord[0];
                entity.y = coord[1];
                entity.id = id;
                entity.otherProperty = properties;
            };
            entitiesCollection.show = bShowLayer;
            this._viewer.dataSources.add(entitiesCollection);
            // if(this._pointLayer){
            //     this._pointLayer.set(layerName,bShowLayer);
            // }
            if(instance._layerDisplayCondition){
                instance.setLayerDisplayCondition(layerName,data.minDisplayAltitude,data.maxDisplayAltitude,true);
                _iniLayerDisplayConditionVisible(this,layerName,bShowLayer);
            }
        }
    })
};

/**
 * 添加线图层
 * bShowLayer: 默认显示加载层
 * distanceDisplay:图层的显示范围，目前修改为在setLayerDisplayCondition中设置图层的最大最小显示比例
 *                 有点是：同个图层具有相同的显隐性，而不会出现应为相机高度不同而出现同个图层某些要素显示而另一些要素隐藏。
 */
vtron.comp.std.map.Cesium.prototype.loadPolylineLayerGeoJsonData = function(layerName, url, width=5, color='rgba(0,200,0,0.8)', glowPower = 0.02, distanceDisplay = 1000, bShowLayer = true,styleEx=null) {
    if(styleEx==null){
        var datasource = Cesium.GeoJsonDataSource.load(url);
        var instance = this;
        datasource.then((data) => {
            data.name = layerName;
            for(var i = 0, len = data.entities.values.length; i < len; i++) {
                var entity = data.entities.values[i];
                //entity.show = bShowLayer;
                var polyline = entity._polyline;
                // polyline.material = glowMatrial; 
                
                polyline.material = Cesium.Color.fromCssColorString(color); 
                //polyline.material = Cesium.Color.fromRandom({alpha : 1.0});
                polyline.width = this.imageScaleFactor * width;
                //polyline.distanceDisplayCondition = new Cesium.DistanceDisplayCondition(0.0, distanceDisplay);
            }
            data.show = bShowLayer;
            if(instance._layerDisplayCondition){
                instance.setLayerDisplayCondition(layerName,data.minDisplayAltitude,data.maxDisplayAltitude,true);
                _iniLayerDisplayConditionVisible(this,layerName,bShowLayer);
            }
        });
    }
    else{
        //模拟道路  未测
        
        // styleEx = {
        //     baseWidth：10,
        //     baseColor ：Cesium.Color.WHITE,
        //     baseImage:,
        //     centerLineWidth: 50 ,//像素
        //     centerLineColor: Cesium.Color.WHITE
        // };
        var tmaterial = new Cesium.ImageMaterialProperty({
              image : styleEx.baseImage||"",
              repeat : new Cesium.Cartesian2(1, 1)
        });

        this._dsLayer.url = url;
        this._dsLayer.load({
            success: (data) => {
                data.features.forEach((line) => {
                    var wgs84_data=[]; 
                    for(var i=0;i<line.geometry.coordinates.length;i++){
                        wgs84_data.push(line.geometry.coordinates[i][0]);
                        wgs84_data.push(line.geometry.coordinates[i][1]);
                    }
                        this._viewer.entities.add({
                           //name : 'Red line on terrain',
                            orridor:{
                                positions : Cesium.Cartesian3.fromDegreesArray(wgs84_data),
                                width : styleEx.baseWidth||50,//100.0,
                               // material : tmaterial,
                                clampToGround : true,
                                outline:true,
                                outlineColor : Cesium.Color.WHITE,
                                cornerType: Cesium.CornerType.BEVELED               
                            },
                            polyline : {
                                positions : Cesium.Cartesian3.fromDegreesArray(wgs84_data),
                                width :styleEx.centerLineWidth,
                                material : new Cesium.PolylineGlowMaterialProperty({
                                    glowPower : 0.1,
                                    color : Cesium.Color.WHITE,//styleEx.centerLineColor
                                }),
                                clampToGround : true
                            }
                       });
                })
            }
        });
    }
    //datasource.show = bShowLayer;
    this._viewer.dataSources.add(datasource);
};

/**
 * 添加建筑物图层
 * bShowLayer: 默认显示加载层
 * type:0 普通的显示
 *      1  拔高处理
 */
vtron.comp.std.map.Cesium.prototype.loadPolygonLayerGeoJsonData = function(layerName, url, imageUrl, bShowLayer = true,fillColor='rgba(255,0,0,0.6)',outlineColor='rgba(0,200,0,0.8)',type=0) {
    this._dsLayer.url = url;
    if(type==0){
        var entitiesCollection = this.getDataSourceByName(layerName);
        if(!entitiesCollection) {
            entitiesCollection = Cesium.GeoJsonDataSource.load(url, {
                stroke: Cesium.Color.fromCssColorString(outlineColor),
                fill: Cesium.Color.fromCssColorString(fillColor),
                strokeWidth: 3
                //name:layerName
            });
            entitiesCollection.then((data) => {
                data.show = bShowLayer;
                data.name = layerName;
                this._viewer.dataSources.add(data);
            });
        }
    }
    else{
        this._dsLayer.load({
            success: (data) => {
                if(data.data && !data.data.length) return;
                var material = new Cesium.ImageMaterialProperty({
                    image: imageUrl,
                    // repeat: new Cesium.Cartesian23(0.5, 0.5),
                    transparent: true
                });
                var entitiesCollection = this.getDataSourceByName(layerName);
                if(!entitiesCollection) {
                    entitiesCollection = new Cesium.CustomDataSource(layerName);
                    this._viewer.dataSources.add(entitiesCollection);
                }
                for(var i = 0, len = data.features.length; i < len; i++) {
                    var coord = data.features[i].geometry.coordinates;
                    var properties = data.features[i].properties;
                    var id = data.features[i].id,
                        positions = [],
                        maxHeights = [];
                    properties.HIGHT = properties.HIGHT || 0;
                    for(var j = 0, len2 = coord.length; j < len2; j++) {
                        var points = coord[j];
                        // 防止多边形不闭合
                        if(JSON.stringify(points[0]) != JSON.stringify(points[points.length -1])) {
                            points.push(points[0]);
                        }
                        for(var k = 0, len3 = points.length; k < len3; k++) {
                            positions.push(points[k][0]);
                            positions.push(points[k][1]);
                            maxHeights.push(properties.HIGHT);
                        }
                    }
                    let entity = entitiesCollection.entities.add({
                        id: id,
                        name: layerName,
                        polygon: {
                            hierarchy: Cesium.Cartesian3.fromDegreesArray(positions),
                            material: Cesium.Color.fromCssColorString('#85fbc8').withAlpha(0.9),
                            outlineColor: Cesium.Color.fromCssColorString('#27cdeb').withAlpha(1),
                            outline: true,
                            height: properties.HIGHT
                        },
                        wall: {
                            positions:  Cesium.Cartesian3.fromDegreesArray(positions),
                            maximumHeights: maxHeights,
                            material: material,
                        }
                    });
                    //entity.show = bShowLayer;
                    entity.layerName = layerName;
                    entity.otherProperty = properties;
                    entity.height = properties.HIGHT;
                    entity.heightNums = coord[0].length;
                };
                entitiesCollection.show = bShowLayer;
            }
        })
    }
};

/**
 * 添加部分点, 指定图层的名称，在相应的图层下添加点，否则建立临时层存部分点
 * layerName：alert|gps|yiyuan, bShowLayer: 默认显示加载层
 */
vtron.comp.std.map.Cesium.prototype.addPointElement = function(layerName, dataInfo, imageUrl, scale = 1, height = 0, bShowLayer = true, supportSearch = false) {
    if(!this._viewer) return;
    if(!layerName) layerName = 'tempLayer';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        supportSearch && this.searchLayerArray.push(layerName);
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }

    datasource.imageSrc = imageUrl;

    if(!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    var instance = this;
    dataInfo.forEach((data) => {
        if(data.x&&data.y){
            var position = Cesium.Cartesian3.fromDegrees(data.x, data.y, height);
            var entity = datasource.entities.getById(data.id);
            var imagematerial = data.imageUrl||imageUrl;
            var imagePicked = data.imageUrlPicked;
            if(data.imageType=='apng'){
                imagematerial = addApng(instance,data.imageUrl);//billboard的apng不能动！
            }
            if(entity){
                //先只更新坐标和图片
                entity.position=position;

                entity.billboard.image = imagematerial;
            }
            else{
                entity = datasource.entities.add({
                    id: data.id,
                    name:layerName,
                    position: position,
                    billboard: {
                        image : imagematerial,//data.imageUrl||imageUrl,
                        scale: this.imageScaleFactor * scale,
                        verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                        scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                        //distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0.0, 200000)
                    }
                });        
            }

            entity.imageSrc = imagematerial;//imageUrl||data.imageUrl;//初始设置的图标
            entity.imagePicked = imagePicked;
            entity.show = (typeof(data.Visibility)=="boolean")?data.Visibility:bShowLayer;
            entity.layerName = layerName;
            entity.start_x = data.x;//记录点的初始位置 chkun
            entity.start_y = data.y;
            entity.distance = null;
            entity.normalize = null;
            entity.vec = null;
            //entity.pathTrack = [data.x,data.y,0]; 
            entity.pathTrack = []; 
        }
        else{
            var entity = datasource.entities.getById(data.id);
            if(!entity){
                entity = datasource.entities.add({
                        id: data.id,
                        billboard: {
                            image : data.imageUrl||imageUrl,
                            scale: this.imageScaleFactor * scale,
                            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                            scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                        },
                        name:layerName,
                    }); 
                entity.pathTrack = []; 
            }
        }  
        
        entity.pathRender = [];  
        entity.x = data.x;        
        entity.y = data.y;
        entity.otherProperty = data.info;
        entity.geoType = 'point' 
    });
};

/*
* addPointElementEx 将丢弃
 */
vtron.comp.std.map.Cesium.prototype.addPointElementEx = function(layerName, dataInfo, imageUrl, scale = 1, height = 0, bShowLayer = true, supportSearch = false) {
    if(!this._viewer) return;
    if(!layerName) layerName = 'tempLayer';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        supportSearch && this.searchLayerArray.push(layerName);
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }

    // if(this._pointLayer){
    //     this._pointLayer.set(layerName,bShowLayer||true);
    // }

    if(!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var position = Cesium.Cartesian3.fromDegrees(data.x, data.y, height);
        var entity = datasource.entities.add({
            id: data.id,
            position: position,
            billboard: {
                image : data.imageUrl||imageUrl,
                scale: this.imageScaleFactor * scale,
                verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                //distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0.0, 200000)
            }
        });
        entity.x = data.x;
        entity.y = data.y;
        entity.otherProperty = data.info;
        entity.show = bShowLayer;
    });
};

/*
*  设置点位置跟踪 ：针对GPS图层（动态点图层）
*  layername：图层名
*  dataInfo：点实体的id array
*  swithch: true：开启跟踪，当点位置变化时，会抛出事件
*           false:关闭跟踪，不再监听点位置变化，不抛事件
 */
vtron.comp.std.map.Cesium.prototype.setPointPositionTrack = function(layerName, dataInfo,track=false) {
    //查找到该点，并设置点的tracked属性
    if(!layerName) return '未设置图层名！';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        return '图层不存在！';
    }
    
    if(!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data);
        if(entity){
           entity.tracked = track;
        }
        else{
            //return '点不存在！';
        }
    });
};

/**
 * 添加Primitive平面，适用与需要修改方向的面
 * height2:距离地面的高度
 * GPS带拖尾
 */
vtron.comp.std.map.Cesium.prototype.addPrimitivePanel = function(layerName, dataInfo, imageUrl, width, height, height2 = 10, bShowLayer = true) {
    if(!this._viewer||!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    var primitiveCollection = this.getPrimitiveCollectionByName(layerName);
    if(!primitiveCollection) {
        primitiveCollection = new Cesium.PrimitiveCollection();
        primitiveCollection.name = layerName;
        this._viewer.scene.primitives.add(primitiveCollection);
    }
    // 角度初始化
    var heading = Cesium.Math.toRadians(0.0),
        pitch = 0,
        roll = 0.0,
        hpr = new Cesium.HeadingPitchRoll(heading, pitch, roll);

    fetch(imageUrl).then((response) => {
        return response.blob();
    }).then((imageBlob) => {
        let image = new Image();
        image.src = URL.createObjectURL(imageBlob);
        let material = new Cesium.Material({
            translucent: true,
            fabric: {
                type: 'Image',
                uniforms: {
                    image: imageUrl,
                },
            },
        });
        material._textures['image'] = new Cesium.Texture({
            context: this._viewer.scene.frameState.context,
            source: {
                width: 1,
                height: 1,
                arrayBufferView : new Uint8Array([255, 255, 0, 0])
            }
        });
        material._loadedImages.push({'id': 'image','image': image});
        var appearance = new  Cesium.EllipsoidSurfaceAppearance({
            // flat: true,  // 光影响了图片显示
            // renderState: {
            //     depthTest: {
            //         enabled: true // 透明度叠加有重影
            //     },
            // },
            material: material
        }); 
        dataInfo.forEach((item) => {
            var position = Cesium.Cartesian3.fromDegrees(item.x, item.y, height2);
            var orientation = Cesium.Transforms.headingPitchRollQuaternion(position, hpr); 
            var instance = new Cesium.GeometryInstance({
                id: item.id,
                geometry: new Cesium.PlaneGeometry({
                    vertexFormat: Cesium.VertexFormat.ALL
                }),
            });
            var primitive = new Cesium.Primitive({
                geometryInstances: instance,
                appearance: appearance,  
                modelMatrix: Cesium.Matrix4.fromTranslationQuaternionRotationScale(
                    position, 
                    orientation, 
                    new Cesium.Cartesian3(width, height, 1.0),
                    new Cesium.Matrix4()),
            });
            primitive.id = item.id;
            primitive.otherProperty = item;
            primitive.scale = new Cesium.Cartesian3(width, height, 1.0);
            primitiveCollection.add(primitive);
        });
    });
};

/**
 * 绘线,更新线顶点,前提是层和id都存在才能更新线顶点
 * vertices: 世界坐标系下的顶点集合
 * 使用回调的方式更新顶点，会解决绘线时的闪烁
 * linetype:'corridor'  默认是‘走廊’的线样式，单位是米，但是某些情况下用该样式绘制线有错误
 *           'polyline',普通的线，单位是像素
 * coordinateSystem:'cartesian'   3D笛卡尔坐标（x,y,z）
 *                   'ellipsoidal' 经纬度+高度
 */
vtron.comp.std.map.Cesium.prototype.addLineElement = function(layerName, id, vertices, width, color, outlineColor = 'rgba(255, 0, 0, 0)', height = 0,coordinateSystem='cartesian',lineType='corridor') {
    if(!this._viewer) return;
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }
    color = color || this.lineColor;
    var entity = datasource.entities.getById(id);

    var entityPosition;
    if(coordinateSystem=='cartesian'||!coordinateSystem){
        entityPosition = vertices;
    }
    else if(coordinateSystem=='ellipsoidal'){
        entityPosition = Cesium.Cartesian3.fromDegreesArray(vertices);
    }
    // 线节点存在则只更新线的顶点，否则需要增加新的线节点
    if(entity) {
        entity.positions = entityPosition;//vertices;
    } else {
        if(lineType=='corridor' || !lineType){
            var entity = datasource.entities.add({
                id: id,
                corridor: {
                    positions: entityPosition,//vertices,
                    width: width,
                    height: height,
                    material: Cesium.Color.fromCssColorString(color),
                    outline: true, 
                    outlineColor: Cesium.Color.fromCssColorString(outlineColor),
                }
            });
            entity.positions = entityPosition;//vertices;
            // 属性回调会影响地图场景性能，有待检查
            entity.corridor.positions = new Cesium.CallbackProperty(() => {return entity.positions}, false);
            entity.geoType='corridor';
        }
        else if(lineType=='polyline'){
            var entity = datasource.entities.add({
                id: id,
                polyline: {
                    positions: entityPosition,//vertices,
                    width: width,
                    height: height,
                    material: Cesium.Color.fromCssColorString(color),
                    outline: true, 
                    outlineColor: Cesium.Color.fromCssColorString(outlineColor),
                }
            });
            entity.positions = entityPosition;
            entity.polyline.positions = new Cesium.CallbackProperty(() => {return entity.positions}, false);
            entity.geoType='polyline';
        }
    }
};

/**
 * 绘多边形
* coordinateSystem:'cartesian'   3D笛卡尔坐标（x,y,z）
 *                   'ellipsoidal' 经纬度+高度
 */
vtron.comp.std.map.Cesium.prototype.addPolygonElement = function(layerName, id, vertices, color, outlineColor = 'rgba(255, 255, 0, 0)', height = 0,coordinateSystem='cartesian') {
    if(!this._viewer) return;
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }
    color = color || this.polygonColor;
    var entity = datasource.entities.getById(id);

    var entityPosition;
    if(coordinateSystem=='cartesian'||!coordinateSystem){
        entityPosition = vertices;
    }
    else if(coordinateSystem=='ellipsoidal'){
        entityPosition = Cesium.Cartesian3.fromDegreesArray(vertices);
    }

    // 线节点存在则只更新线的顶点，否则需要增加新的多边形节点
    if(entity) {
        entity.hierarchy = vertices;
    } else {
        var entity = datasource.entities.add({
            id: id,
            polygon: {
                hierarchy: entityPosition,
                //height: height,
                material: Cesium.Color.fromCssColorString(color),
                outline: true,
                outlineColor: Cesium.Color.fromCssColorString(outlineColor),
            }
        });
        entity.hierarchy = vertices;
        entity.polygon.hierarchy = new Cesium.CallbackProperty(() => {return entity.hierarchy}, false);
        entity.geoType='polygon';
    }
};

/**
 * 
 */
vtron.comp.std.map.Cesium.prototype.addCircleOutlineElement = function(layerName,id,center, radius,width,color){
    if(!this._viewer) return;
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }
    var entity = datasource.entities.getById(id);
    if(entity) {
        entity.radius = radius;
    } else {
        var instance = this._viewer;
        //由于webgl限制outlinewidth<=1,因此需要在填充的圆的边缘多加一个polyline_circle entity
        var GetOutlineVertex = function(center,radius){
            var circle = new Cesium.CircleOutlineGeometry({
                center : center,//Cesium.Cartesian3.fromDegrees(center.x, center.y),
                radius : radius
            });

            var geometry1 = Cesium.CircleOutlineGeometry.createGeometry(circle);
            var circle_outline_vertex = geometry1.attributes.position.values;
            var linedata = [];
            //var linedataBB=[];
            //var xmax=-180,xmin=180,ymax=-90;ymin=90;
            for(var vertexid=0;vertexid<circle_outline_vertex.length-2;vertexid+=3){
                linedata.push(new Cesium.Cartesian3(circle_outline_vertex[vertexid],circle_outline_vertex[vertexid+1],circle_outline_vertex[vertexid+2])) ;
                
                //测试
                /*var ellipsoid=instance.scene.globe.ellipsoid;
                var cartesian3=new Cesium.Cartesian3(circle_outline_vertex[vertexid],circle_outline_vertex[vertexid+1],circle_outline_vertex[vertexid+2]);
                var cartographic=ellipsoid.cartesianToCartographic(cartesian3);
                var lat=Cesium.Math.toDegrees(cartographic.latitude);
                var lng=Cesium.Math.toDegrees(cartographic.longitude);
                if(lng<xmin) xmin= lng;
                if(lng>xmax) xmax = lng;
                if(lat<ymin) ymin = lat;
                if(lat>ymax) ymax = lat; */
            }
            /*instance.lonmin = xmin;
            instance.lonmax = xmax;
            instance.latmin = ymin;
            instance.latmax = ymax;*/
            //首尾相连接，构成闭合线
            linedata.push(new Cesium.Cartesian3(circle_outline_vertex[0],circle_outline_vertex[1],circle_outline_vertex[2])) ;
            return linedata;
        }
        
        var linevertex =  GetOutlineVertex(center,radius);
        var entity = datasource.entities.add({
            id: id,
            polyline: {
                positions:linevertex,
                material: Cesium.Color.fromCssColorString(color),
                width: width,
                clampToGround : true
            }
        });
        entity.radius = radius;
        entity.center = center;
        entity.polyline.positions = new Cesium.CallbackProperty(() => {
            return GetOutlineVertex(center,radius);
        }, false);
    }
};

/**
 * 绘圆: 设置高度outlineColor才生效
 */
vtron.comp.std.map.Cesium.prototype.addCircleElement = function(layerName, id, center, radius = 1, color, outlineColor = 'rgba(255, 255, 0, 0)', outlineWidth=1,height = 0) {
    if(!this._viewer) return;
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }
    color = color || this.circleColor;
    var entity = datasource.entities.getById(id);
    if(entity) {
        entity.radius = radius;
    } else {
        var entity = datasource.entities.add({
            id: id,
            position: center,
            ellipse: {
                semiMinorAxis: radius,
                semiMajorAxis: radius,
                height: 0,
                material: Cesium.Color.fromCssColorString(color),
                //outline: true,
                //outlineColor: Cesium.Color.fromCssColorString(outlineColor),
                //outlineWidth: outlineColor,
            }
        });
        entity.radius = radius;
        entity.ellipse.semiMinorAxis = new Cesium.CallbackProperty(() => {return entity.radius}, false);
        entity.ellipse.semiMajorAxis = new Cesium.CallbackProperty(() => {return entity.radius}, false);
        entity.geoType='circle';
    }

    //由于webgl限制outlinewidth<=1,因此需要在填充的圆的边缘多加一个polyline_circle entity
    if(outlineWidth>1){
        this.addCircleOutlineElement(layerName,id+".outline",center,radius,outlineWidth,outlineColor);
    }
};

/**
 * 修改部分点样式:修改图标数据和图标大小
 */
vtron.comp.std.map.Cesium.prototype.pointsChangeStyle = function(layerName, dataInfo, imageUrl, scale = 1) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource || !dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data.id);
        if(entity&&entity.billboard) {
            if(data.imageUrl || imageUrl){
                entity.billboard.image = data.imageUrl||imageUrl;
                entity.imageSrc = data.imageUrl||imageUrl;
            }
            if(data.imageUrlPicked){
                entity.imagePicked = data.imageUrlPicked;
            }
            entity.billboard.scale = this.imageScaleFactor*scale;
        }
    });
};

/**
 * 修改线的样式：宽度和颜色
 * 用corridor：以米为单位，用在线选
 */
vtron.comp.std.map.Cesium.prototype.lineChangeStyle = function(layerName, dataInfo, width, color,linetype='corridor') {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource || !dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data.id||'lineChangeStyle');
        if(entity) {
            if(linetype=='corridor'){
                entity.corridor.width = data.width || width; //chkun
                entity.corridor.material = Cesium.Color.fromCssColorString(data.color || color);//chkun
            }
            else if(linetype=='polyline'){
                entity.polyline.material = Cesium.Color.fromCssColorString(data.color || color);
                entity.polyline.width = data.width || width; 
            }
        }
    });
};

/**
 * 修改面的样式：颜色
 */
vtron.comp.std.map.Cesium.prototype.polygonChangeStyle = function(layerName, dataInfo, color) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource || !dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data.id);
        if(entity) {
            entity.polygon.material = Cesium.Color.fromCssColorString(color);
        }
    });
};

/**
 * 修改primitive的样式：修改图片和大小
 */
vtron.comp.std.map.Cesium.prototype.planeChangeStyle = function(layerName, dataInfo, imageUrl, width, height) {
    let layer = this.getPrimitiveCollectionByName(layerName);
    if(!layer || !dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var primitives = this.getPrimitiveById(layerName, data.id);
        primitives.forEach((item) => {
            if(imageUrl) {
                item.material.uniforms.image = imageUrl;
            }
            if(width && height) {
                item.scale = new Cesium.Cartesian3(width, height, 1.0);
            }
        });
    });
};

/**
 * 修改所有primitive的统一样式，比如缩放
 */
vtron.comp.std.map.Cesium.prototype.planeChangeStyleAll = function(layerName, imageUrl, width, height) {
    let layer = this.getPrimitiveCollectionByName(layerName);
    if(!layer) return;
    layer._primitives.forEach((item) => {
        if(item instanceof Cesium.Primitive) {
            if(imageUrl) {
                item.material.uniforms.image = imageUrl;
            }
            if(width && height) {
                item.scale = new Cesium.Cartesian3(width, height, 1.0);
            }
        }
    });
};

/**
 * 修改点的地理坐标
 * layerName:图层名
 * dataInfo：[{'id':'gps-1','x':,'y':}]
 */
vtron.comp.std.map.Cesium.prototype.movePoints = function(layerName, dataInfo,animate=false) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource || !dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data.id);
        if(entity) {
            var position = Cesium.Cartesian3.fromDegrees(data.x, data.y);
            entity.position = position;
            entity.x = data.x;
            entity.y = data.y;
        }
    });
};

/*
   单位向量
 */
function cluculateInterpolationNormalize(startPoint, endPoint){
    var a = glm.vec3(endPoint.x - startPoint.x, endPoint.y - startPoint.y, 0);
    var l = glm.normalize(a);
    return l;
}

/* 计算两个点之间的插值点
*/
function cluculateInterpolationLength(startPoint, endPoint) {
    var length = glm.distance(glm.vec3(startPoint.x, startPoint.y, 0), glm.vec3(endPoint.x, endPoint.y, 0)); 
    return length;
}
/*
    divide: 占两点间线段的百分比
    lenght:两点长度
 */
function getInterpolationPoint(startPoint, endPoint, divide,entity) {
    var retpoint = {};
    //return startPoint;
    //计算线的长度
    var lineLength=0.0;
    if(entity.distance==null){
       lineLength = cluculateInterpolationLength(startPoint, endPoint);
       entity.distance = lineLength;
    }
    else{
        lineLength = entity.distance;
    }

    //等分线的长度
    var perLength = lineLength * divide;
    var a = glm.vec3(endPoint.x - startPoint.x, endPoint.y - startPoint.y, 0);
    if(entity.vec == null){
        a = glm.vec3(endPoint.x - startPoint.x, endPoint.y - startPoint.y, 0);
        entity.vec = a;
    }
    else{
        a = entity.a;
    }

    var l = 0;
    if(entity.normalize==null){
        l = glm.normalize(a);
        entity.normalize = l;
    }
    else{
        l = entity.normalize;
    }
    var curdis = perLength * divide;
    var p = glm.vec3(l.x * curdis, l.y * curdis, 0);
    retpoint.x = p.x + startPoint.x,
    retpoint.y = p.y + startPoint.y

    return retpoint;
}
/**
 * movepointsex
 * 修改点的地理坐标  平滑移动点
 * layerName:图层名
 * dataInfo：[{'id':'gps-1','x':,'y':,'intervaltime':2000}]
 * entity新加属性
 *    x:点当前的位置lon
 *    y:点当前的位置lat
 *    start_x:点初始lon
 *    start_y:点初始lat
 *    end_x:终点位置lon
 *    end_y:终点位置lat
 *    interval:两点间移动时间间隔
 *    start_time:点开始运动时间
 *    distance:两点间距离
 *    normalize:单位化向量
 *    vec:向量
 *    pathTrack：每次movepointex,都把点保存到数组  [lon,lat,alt,lon,lat,alt...lon,lat,alt]
 *    pathRender:需要显示的路径,是pathTrack的一部分
 *    playPath:是否在启动播放轨迹 true：播放，false：停止
 */
var timeDynamicPoint=false;

_updateDynamicPoint = function(instance){
    for(let data in instance._dynameLayer_dataSource){
        var btrackedpoint = false;
        var dypointArray = [];
        var datasource = instance._dynameLayer_dataSource[data];
        if(datasource.animate!==undefined && datasource.animate == true){
            var curtime = new Date().getTime();
            for(var i=0;i<datasource.entities._entities.length;i++)
            {
                var entity = datasource.entities.values[i];
                if(entity && entity.animate ) {
                    var startpoint={},endpoint={};
                    startpoint.x = entity.start_x;
                    startpoint.y = entity.start_y;
                    endpoint.x = entity.end_x;
                    endpoint.y = entity.end_y;
                    
                    var btimeout = (curtime-entity.start_time)/entity.interval;//>=1则是时间到
                    var curpos = {};
                    curpos.x = endpoint.x;
                    curpos.y = endpoint.y;
                    if(btimeout<=1){
                        //curpos = getInterpolationPoint(startpoint,endpoint,(curtime-entity.start_time)/entity.interval,entity);
                        var m = (curtime-entity.start_time)/entity.interval;
                        curpos.x = startpoint.x + (endpoint.x-startpoint.x)*m;
                        curpos.y = startpoint.y + (endpoint.y-startpoint.y)*m;
                    }
                    else{
                        entity.animate = false;
                        entity.start_x = curpos.x;
                        entity.start_y = curpos.y;
                    }
                    
                    if(entity.tracked==true){
                        btrackedpoint = true;
                        //世界坐标转屏幕坐标
                        var ll2pix = instance.getScreenCoordFromCartographic(curpos.x,curpos.y);
                        //instance.fire("Point-Position-Update", {"layerName": datasource.name, "id": entity.id,"screenCoord":{"x":ll2pix.x,"y":ll2pix.y},"gisCoord":{"lon": curpos.x, "lat": curpos.y}},{bubbles: false});
                        var dypointobject = {};
                        dypointobject.id = entity.id;
                        var screenCoord = {};
                        screenCoord.x = ll2pix.x;
                        screenCoord.y = ll2pix.y;
                        dypointobject.screenCoord = screenCoord;

                        var gisCoord = {};
                        gisCoord.x = curpos.x;
                        gisCoord.y = curpos.y;
                        dypointobject.gisCoord = gisCoord;
                        dypointArray.push(dypointobject);
                    }
                    var position = Cesium.Cartesian3.fromDegrees(curpos.x, curpos.y);
                    entity.position = position;
                    entity._position._value.x = position.x ;
                    entity._position._value.y = position.y ;
                    entity._position._value.z = position.z ;
                    entity.x = curpos.x;
                    entity.y = curpos.y;

                    //计算需要显示的实时轨迹顶点
                    //轨迹=第一个节点前的顶点+
                    if(entity.playRealTimeTrack){
                        var vet = [];
                        if(entity.pathTrack.length>30*3){
                            vet = entity.pathTrack.slice(entity.pathTrack.length-30*3-3,entity.pathTrack.length-3);
                            vet.push(curpos.x,curpos.y,0);
                            entity.pathRender = vet;
                        }else{
                            if(entity.pathTrack.length<=3){
                                //说明是在点运动过程中，开始播放，测试新点还未加到pathTrack中
                                entity.pathRender.push(curpos.x,curpos.y,0);
                                entity.firstPathRenderSeg = entity.pathRender.slice();
                            }
                            else{
                                // if(entity.firstPathRenderSeg)
                                // {
                                    // vet = entity.firstPathRenderSeg.concat(entity.pathTrack.slice(0,entity.pathTrack.length-3));
                                    // vet.push(curpos.x,curpos.y,0);
                                     //entity.pathRender = vet;
                                // }
                                // else{
                                    entity.pathRender.push(curpos.x,curpos.y,0);
                                // }
                            }
                        } 
                    }
                }
            }

            //按图层统一发送所有track的点信息
            if(btrackedpoint){
                var firedata = {};
                firedata.layerName = datasource.name;
                firedata.data = dypointArray;
                instance.fire("Point-Position-Update", firedata,{bubbles: false});
            }
            
        }
    } 
}

vtron.comp.std.map.Cesium.prototype.movePointsEx = function(layerName, dataInfo,animate=true) {

    var datasource = this.getDataSourceByName(layerName);
    if(!datasource || !dataInfo) return;
    datasource.animate = true;
    this._dynameLayer_dataSource[layerName]=datasource;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var entity = datasource.entities.getById(data.id);
        if(entity && animate) {
            var position = Cesium.Cartesian3.fromDegrees(data.x, data.y);
            if(entity.animate==true){
                //当点再运动过程中，接受到新的位置时，用当前的终点作为新的起点
                entity.start_x = entity.end_x;
                entity.start_y = entity.end_y;
            }
            entity.end_x = data.x;
            entity.end_y = data.y;
            entity.interval = data.intervaltime||3000;//default value:3000ms
            entity.start_time = new Date().getTime();
            entity.animate = true;
            entity.normalize = null;
            entity.distance = null;
            entity.vec = null;
            if(entity.playRealTimeTrack){
               //只有在启动实时gps播放才计算
               entity.pathTrack.push(data.x,data.y,0);
            }
        }
    });
    var ViewerObject = this;
    if(timeDynamicPoint == false){
        //创建定时器 30ms 计算更新gps等动态点坐标
        window.setInterval(function(){
            _updateDynamicPoint(ViewerObject);
            },25);
        timeDynamicPoint = true;
    }
};

/**
 * 修改primitive的位置，旋转，目前适用与GPS的更新
 * rotation默认设置heading
 */
vtron.comp.std.map.Cesium.prototype.planeChangePosition = function(layerName, id, lon, lat, rotation = 0) {
    var primitives = this.getPrimitiveById(layerName, id);
    primitives.forEach((item) => {
        let position = Cesium.Cartesian3.fromDegrees(parseFloat(lon), parseFloat(lat), 10),
            // heading = Cesium.Math.toRadians(parseFloat(rotation)),//绕垂直于地心的轴旋转
            heading = parseFloat(rotation),//绕垂直于地心的轴旋转
            pitch = Cesium.Math.toRadians(0.0), //绕纬度线旋转
            roll = Cesium.Math.toRadians(0.0);    //绕经度线旋转
        var hpr = new Cesium.HeadingPitchRoll(heading, pitch, roll);
        var orientation = Cesium.Transforms.headingPitchRollQuaternion(position, hpr); 
        var modelMatrix = Cesium.Matrix4.fromTranslationQuaternionRotationScale(position, orientation, item.scale);
        item.modelMatrix = modelMatrix;
    });
};

/**
 * 按名称查找指定datasource
 * 存在则返回datasource，不存在则返回false
 */
vtron.comp.std.map.Cesium.prototype.getDataSourceByName = function(layerName) {
    if(!this._viewer || !this._viewer.dataSources) return null;
    for(let dataSource of this._viewer.dataSources._dataSources) {
        if(dataSource.name == layerName) {
            return dataSource;
        }
    }
    return null;
};

/**
 * 按index查找指定datasource
 * 存在则返回datasource，不存在则返回false
 */
vtron.comp.std.map.Cesium.prototype.getDataSourceByIndex = function(index) {
    if(!this._viewer) return null;
    var datasource = this._viewer.dataSources.get(index);
    return datasource;
};

/**
 * datasource集合的长度
 * 存在则返回datasource，不存在则返回false
 */
vtron.comp.std.map.Cesium.prototype.getDataSourcelength = function() {
    if(!this._viewer) return 0; 
    return this._viewer.dataSources.length;
};

/**
 * 按名称查找指定primitiveCollection
 * 存在则返回primitiveCollection，不存在则返回false
 */
vtron.comp.std.map.Cesium.prototype.getPrimitiveCollectionByName = function(layerName) {
    if(!this._viewer || !this._viewer.scene.primitives) return null;
    for(let primitive of this._viewer.scene.primitives._primitives) {
        if(primitive.name == layerName) {
            return primitive;
        }
    }
    return null;
};

/**
 * 查找entity对应的primitive,调整entity的位置和旋转,目前适用与GPS的更新
 * 返回值是数组,因为平面有可能带宽度，设置宽度会新增一个primitive
 */
vtron.comp.std.map.Cesium.prototype.getPrimitiveById = function(layerName, id) {
    let result = [],
        primitiveCollection = null;
    primitiveCollection = this.getPrimitiveCollectionByName(layerName);
    if(primitiveCollection) {
        var primitives = primitiveCollection._primitives;
        primitives.forEach((item) => {
            if(item instanceof Cesium.Primitive) {
                if(item.id == id) {
                    result.push(item);
                    return;
                }
            }
        });
        return result;
    } 
};

/**
 * 查找entity
 */
vtron.comp.std.map.Cesium.prototype.getEntityById = function(layerName, id) {
    var datasource = this.getDataSourceByName(layerName);
    var result = null;
    if(datasource) {
        result = datasource.entities.getById(id);
    }
    return result;
};

/**
 * 批量显示批量隐藏点\线\面;
 * 如果图层隐藏，则修改图层状态为显示
 * 如果fids为空或者未定义，表示需要设置某图层的所有要素为显示状态，但并不修改图层本省的显隐状态
 */
vtron.comp.std.map.Cesium.prototype.showElements = function(layerName, fids) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) return;
    //if(!fids||!fids.length) return;
    if(!(fids instanceof Array)) fids = [fids];
    //datasource.show = true;
    if(!fids||!fids.length) {
        datasource.entities.values.forEach(entity => entity.show = true);
    } else {
        fids.forEach(id => {
          var entity = datasource.entities.getById(id);
          if(entity){
            entity.show = true;
            if(entity.geoType=='circle'){
                //如果是圆要素，则需要把圆的outline实体也显示
                var circleOutlineEntity = datasource.entities.getById(id+'.outline');
                if(circleOutlineEntity){
                    circleOutlineEntity.show = true;
                }   
            }
          }    
        })
    }
    //this._viewer.scene.requestRender();
};

/**
 * 批量隐藏点\线\面，不传参数，全部隐藏
 * 如果fids为空或者未定义，表示需要设置某图层的所有要素为显示状态，但并不修改图层本省的显隐状态
 */
vtron.comp.std.map.Cesium.prototype.hideElements = function(layerName, fids) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) return;
    //if(!fids||!fids.length) return;
    if(!(fids instanceof Array)) fids = [fids];
    if(!fids||!fids.length) {
        datasource.entities.values.forEach(entity => entity.show = false);
    } else {
        fids.forEach(id => {
          var entity = datasource.entities.getById(id||'test');//'test'避免id未定义时的错误
          if(entity){
            entity.show = false;
            if(entity.geoType=='circle'){
                //如果是圆要素，则需要把圆的outline实体也隐藏
                var circleOutlineEntity = datasource.entities.getById(id+'.outline');
                if(circleOutlineEntity){
                    circleOutlineEntity.show = false;
                }   
            }
          }
        })
    }
    //this._viewer.scene.requestRender();
};

/**
 * 删除隐藏点\线\面，和layerdelete功能重叠，但是对于组件的接口封装来说，deleteelements接口更直观
 * fids为空或者不定义，则标识删除图层中所有的实体（entity）
 */
vtron.comp.std.map.Cesium.prototype.deleteElements = function(layerName, fids) {
    var datasource = this.getDataSourceByName(layerName);
    if(!(fids instanceof Array)) fids = [fids];
    if(datasource) {
        if(!fids||!fids.length) {
            datasource.entities.removeAll();
        } else {
            if(datasource.pathTrackingLayer){
                //如果是轨迹图层，则需要删除额外的点
                datasource.entities.removeAll();
            }
            else{
                fids.forEach(id => {
                    var entity = datasource.entities.getById(id);
                    if(entity&&entity.geoType=='circle'){
                        //如果是圆要素，则需要把圆的outline实体也删除 
                        var circleOutlineEntity = datasource.entities.getById(id+'.outline');
                        if(circleOutlineEntity){
                            datasource.entities.removeById(id+'.outline');
                        }   
                    }
                    datasource.entities.removeById(id);
                })
            }
        }
    }
};

/**
 * 显示指定名称的图层（dataSource || primitive）,默认操作DataSource类型图层
 */
vtron.comp.std.map.Cesium.prototype.layerShow = function(layerName, bPrimitive = false,ballElementShow=false) {
    var layer = null;
    if(!bPrimitive) {
        layer = this.getDataSourceByName(layerName);
        if(ballElementShow){
            //强制所有点显示
            layer.entities.values.forEach(entity => entity.show = true);
        }
    } else {
        layer = getPrimitiveCollectionByName(layerName);
    }
    if(layer) {
        layer.show = true;
        // if(this._pointLayer&&this._pointLayer.get(layerName)){
        //     this._pointLayer.set(layerName,true);
        // }
        //设置图层的显隐属性
        if(this._layerDisplayCondition){
            var layerDisInfo = this._layerDisplayCondition.get(layerName)
            if(layerDisInfo){
                layerDisInfo.visible = layer.show;
            }
        }

        this._viewer.scene.requestRender();
        this.fire("layer-show", {"layerName": layerName, show: true, bPrimitive: bPrimitive}, {bubbles: false});
    }
};

/**
 * 隐藏指定名称的图层（dataSource || primitive）,默认操作DsataSource类型图层
 */
vtron.comp.std.map.Cesium.prototype.layerHide = function(layerName, bPrimitive = false,ballElementHide=false) {
    var layer = null;
    if(!bPrimitive) {
        layer = this.getDataSourceByName(layerName);
        if(ballElementHide){
            //强制所有点隐藏
            layer.entities.values.forEach(entity => entity.show = false);
        }
    } else {
        layer = getPrimitiveCollectionByName(layerName);
    }
    if(layer) {
        layer.show = false;
        // if(this._pointLayer&&this._pointLayer.get(layerName)){
        //     this._pointLayer.set(layerName,false);
        // }
        //设置图层的显隐属性
        if(this._layerDisplayCondition){
            var layerDisInfo = this._layerDisplayCondition.get(layerName)
            if(layerDisInfo){
                layerDisInfo.visible = layer.show;
            }
        }
        this._viewer.scene.requestRender();
        this.fire("layer-show", {"layerName": layerName, show: false, bPrimitive: bPrimitive}, {bubbles: false});
    }
};

/**
 * 删除指定名称的图层
 * layerName不设置的时候，则清除6类图层
 * dataInfo是id数组，不为空的时候，则删除指定名称图层的某些元素
 */
vtron.comp.std.map.Cesium.prototype.layerDelete = function(layerName, dataInfo, bPrimitive = false) {
    if(!layerName) {
        ['choose-line', 'draw-line', 'choose-polygon', 'choose-circle', 'draw', 'tempLayer'].forEach((name) => {
            let datasource = this.getDataSourceByName(name);
            datasource && this._viewer.dataSources.remove(datasource, true);
        });
        return;
    }
    if(!bPrimitive) {
        var datasource = this.getDataSourceByName(layerName);
        if(datasource) {
            if(dataInfo) {
                if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
                for(let id of dataInfo) {
                    datasource.entities.removeById(id);
                }
            } else {
                this._viewer.dataSources.remove(datasource, true);
                // if(this._pointLayer&&this._pointLayer.get(layerName)){
                //     this._pointLayer.delete(layerName);
                // }
                
                if(this._layerDisplayCondition){
                    var layerDisInfo = this._layerDisplayCondition.get(layerName)
                    if(layerDisInfo){
                        this._layerDisplayCondition.delete(layerName);
                    }
                }
            }
        }
    } else {
        var layer = this.getPrimitiveCollectionByName(layerName);
        if(layer) {
            if(dataInfo) {
                if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
                for(let id of dataInfo) {
                   var primitiveCollection = this.getPrimitiveById(layerName, id);
                   for(let primitive of primitiveCollection) {
                        primitive.destroy();
                   }
                }
            } else {
                layer.destroy();
            }
        }
    }
};

/**
 * 删除场景所有的datasource
 */
vtron.comp.std.map.Cesium.prototype.layerDeleteAll = function(bPrimitive = false) {
    if(!bPrimitive) {
        this._viewer.dataSources.removeAll(true);
        // if(this._pointLayer&&this._pointLayer.get(layerName)){
        //     this._pointLayer.delete(layerName);
        // }
        if(this._layerDisplayCondition){
            this._layerDisplayCondition.clear();
        }
    } else {
        this._viewer.scene.primitives.destroy();
    }
};

/**
 * 返回图层是否隐藏
 */
vtron.comp.std.map.Cesium.prototype.layerHidden = function(layerName, bPrimitive = false) {
    var layer = null;
    if(!bPrimitive) {
        layer = this.getDataSourceByName(layerName);
    } else {
        layer = getPrimitiveCollectionByName(layerName);
    }
    if(layer) {
        return !layer.show;
    }
    throw Error(layerName + '图层不存在');
};
/*
 *设置图层的显示范围
 *layerName:图层名
 *minAlt：最小显示高度
 *maxAlt：最大显示高度
 *visible:是否需要修改图层显隐属性（通过layerShow和layerHide设置，如果当前距离在minAlt和maxAlt之间时，图层显隐由visible属性控制）
 *
 */
vtron.comp.std.map.Cesium.prototype.setLayerDisplayCondition = function(layerName,minAlt=0,maxAlt=200000){
    if(!this._viewer || !this._layerDisplayCondition) return;
    var layerDisInfo={};
    layerDisInfo.minDisplayAltitude = minAlt||0;
    layerDisInfo.maxDisplayAltitude = maxAlt||200000;
    //layerDisInfo.visible = undefined;
    this._layerDisplayCondition.set(layerName,layerDisInfo);
};

/*
 *内部函数，在loadpoly***图层以后，设置layerDisInfo.visible
 *map2:mapengine2实例
 */
var _iniLayerDisplayConditionVisible=function(map2,layerName,visible){
    if(map2._layerDisplayCondition){
        var condition = map2._layerDisplayCondition.get(layerName);
        if(condition){
            condition.visible = visible;
            map2._layerDisplayCondition.set(layerName,condition);
        }
    }
};
/**
 * layerNameArray:搜索层名集合,如果缺省则搜索默认集合this.searchLayerArray
 * 空间搜索: choose-line|draw-line|choose-circle|choose-polygon|move
 * optState操作状态, radius参数只有在操作状态为choose-circle才生效
 * bCmd:true或者undefined表示是指令的调用（不需要再通知其它端进行searchByTurf），false表示地图内部进行选择操作（需要发送给其它端）
 */
vtron.comp.std.map.Cesium.prototype.searchByTurf = function(layerNameArray, optID, optState, vertices, lineWidth, radius = 0, otherProperty,bCmd) {
    var originalPoints = [],
        options = {units: 'meters'},  // 以米为单位
        result = {
            searchPoly: {
                id: optID
            },
            searchResult:[],
            data: otherProperty || {}
        };  // 返回结果集
    if(!layerNameArray) layerNameArray = this.searchLayerArray;
    if(!(layerNameArray instanceof Array)) layerNameArray = [layerNameArray];
    // 将vertices数组转成Geo格式
    vertices.forEach((vertex) => {
        var cart = this.getCartographicFromCartesian(vertex.x, vertex.y, vertex.z);
        originalPoints.push([cart.lon, cart.lat]);
    });

    var searchResultisNull = true;

    switch(optState) {
        case 'choose-line':
            result.searchPoly.Type = 'line';
            result.searchPoly.GeoPolyLineString = vertices;
            result.searchPoly.LineWidth = lineWidth;
            break;
        case 'choose-polygon':
            result.searchPoly.Type = 'polygon';
            result.searchPoly.GeoPolyLineString = vertices;
            break;
        case 'choose-circle':
            result.searchPoly.Type = 'circle';
            result.searchPoly.GeoCenter = vertices[0];
            result.searchPoly.GeoRadius = radius;
            break;
    };
    layerNameArray.forEach((layerName) => {
        var layerResult = [],
            propertiesResult = [],
            datasource = this.getDataSourceByName(layerName);
        if(datasource) {
            switch(optState) {
                case 'choose-line':
                    // 线构建一个面缓冲区
                    var searchResult = [],
                        line = turf.lineString(originalPoints),
                        polyBuffer = turf.buffer(line, lineWidth, options);
                    datasource.entities.values.forEach((entity) => {
                        if(entity.x && entity.y){
                            var pt = turf.point([entity.x, entity.y]);
                            var bChoose = turf.booleanPointInPolygon(pt, polyBuffer);
                            if(bChoose) {
                                searchResult.push(entity);
                            }
                        }
                    });
                    // 排序
                    for(var i = 0, len = originalPoints.length - 1; i < len; i++) {
                        var tempResult = [];
                        var tempLine = turf.lineString(originalPoints.slice(i, i + 2));
                        var tempPolyBuffer = turf.buffer(tempLine, lineWidth, options);
                        searchResult.forEach((item) => {
                            var pt = turf.point([item.x, item.y]);
                            var bChoose = turf.booleanPointInPolygon(pt, tempPolyBuffer);
                            if(bChoose) {
                                var distance = turf.distance(originalPoints[i], pt, options);
                                item.distance = distance;
                                tempResult.push(item);
                            }
                        })
                        tempResult.sort((a, b) => {
                            return a.distance - b.distance;
                        });
                        layerResult = layerResult.concat(tempResult);
                    }
                    break;
                case 'choose-polygon':
                    // 计算多边形的时候，首尾点要一致
                    originalPoints.push(originalPoints[0]);
                    if(originalPoints.length >= 4) {
                        var poly = turf.polygon([originalPoints]);
                        datasource.entities.values.forEach((entity) => {
                            if(entity.x && entity.y){
                                var pt = turf.point([entity.x, entity.y]);
                                var bChoose = turf.booleanPointInPolygon(pt, poly);
                                if(bChoose) {
                                    layerResult.push(entity);
                                }
                            }
                        });
                    }
                    break;
                case 'choose-circle':
                    var from = turf.point(originalPoints[0]);
                    datasource.entities.values.forEach((entity) => {
                        if(entity.x && entity.y){
                            var to = turf.point([entity.x, entity.y]);
                            var distance = turf.distance(from, to, options);
                            if(distance < radius) {
                                entity.distance = distance;
                                layerResult.push(entity);
                            }
                        }
                    });
                    // 搜索结果按距离升序排
                    layerResult.sort((a, b) => {
                        return a.distance - b.distance;
                    });
                    break;
            }
        }
        // layerResult保存的是entity实体
        layerResult.forEach((entity) => {
            propertiesResult.push(entity.otherProperty);
            searchResultisNull = false;
        });
        result.searchResult.push({
            Information: propertiesResult,
            LayerName: layerName
        });
    })

    result.bCmd = bCmd== undefined ? true: bCmd;
    this.fire('elementRangeSelect', result);
    result.searchResultisNull = searchResultisNull;
    return result;
};

/** 
 * 获取内部CesiumViewer对象
 */
vtron.comp.std.map.Cesium.prototype.getInternalMap = function() {
    return this._viewer;
};

/**
 * 遍历_levelZeroTiles四叉树，暂时用于地图反色
 */
vtron.comp.std.map.Cesium.prototype.preorder = function(item) {
    if(!item.data) {
        return;
    }
    this.tileQueueList.push(item);
    this.preorder(item.children[0]);
    this.preorder(item.children[1]);
    this.preorder(item.children[2]);
    this.preorder(item.children[3]);
};

/**
 * 地图反色
 * invertFlag：是否反色的标识，可以丢去
* type：
*      0：原色
*      1：反色
*      2：亮色地图变成黑灰白地图
*      3：亮色地图变成蓝黑色地图
*      4：测试亮地图锐化：突出文字
*      5：测试亮地图锐化：突出文字
*      6：黑地图偏蓝色
 */
vtron.comp.std.map.Cesium.prototype.invertMapColor = function(type=0) {
    //if(this.invertFlag == invertFlag) return;
    this.tileQueueList = [];
    var globe = this._viewer.scene.globe;
    // 清除已经创建的surfaceShader,防止新修改的shader不生效
    globe._surfaceShaderSet._shadersByTexturesFlags = [];
    var baseFragmentShaderSource = globe._surfaceShaderSet.baseFragmentShaderSource;  
    // 修改primitive的levelZeroTiles节点，遍历四叉树
    //if(!globe._surface._levelZeroTiles) return;
    if(globe._surface._levelZeroTiles){
        for(var i = 0, len = globe._surface._levelZeroTiles.length; i < len; i++) {
            this.preorder(globe._surface._levelZeroTiles[i]); 
        }
        this.tileQueueList.forEach((tile) => {
            tile.data.surfaceShader = null;
        });
    }
    
    if(type!=0){
        var fragmentShader = Cesium._shaders['GlobeFS'];
        baseFragmentShaderSource.sources[0] = fragmentShader;
    }
    if(type==0){
        //原色
        var fragmentShader = Cesium._shaders['GlobeFS'];
        this.invertFlag = false;
    }else if(type==1){
        var str = `vec4 finalColor = vec4(vec3(1.0 - color.rgb), color.a)`;
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, str);
        this.invertFlag = true;
    }else if(type==2){
        // 灰度图
        var str = `float gray = 0.3 * color.r + 0.59 * color.g + 0.11 * color.b;
        vec4 finalColor = vec4(vec3(1.0 - gray), color.a)`;
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, str);
        this.invertFlag = true;
    }
    else if(type == 3){
        var str ='\n\
            #ifdef GL_FRAGMENT_PRECISION_HIGH\n\
                precision highp float;\n\
            #else\n\
                precision mediump float;\n\
            #endif\n\
            uniform vec4 u_initialColor;\n\
            float blendColorBurn(float base, float blend) {\n\
                return (blend==0.0)?blend:max((1.0-((1.0-base)/blend)),0.0);\n\
            }\n\
            vec3 blendColorBurn(vec3 base, vec3 blend) {\n\
                return vec3(blendColorBurn(base.r,blend.r),blendColorBurn(base.g,blend.g),blendColorBurn(base.b,blend.b));\n\
            }\n\
            vec3 blendColorBurn(vec3 base, vec3 blend, float opacity) {\n\
                return (blendColorBurn(base, blend) * opacity + base * (1.0 - opacity));\n\
            }\n\
            \n\
            float blendSoftLight(float base, float blend){\n\
                return (blend<0.5)?(2.0*base*blend+base*base*(1.0-2.0*blend)):(sqrt(base)*(2.0*blend-1.0)+2.0*base*(1.0-blend));\n\
            }\n\
            vec3 blendSoftLight(vec3 base, vec3 blend){\n\
                return vec3(blendSoftLight(base.r,blend.r),blendSoftLight(base.g,blend.g),blendSoftLight(base.b,blend.b));\n\
            }\n\
            \n\
            vec3 blendSoftLight(vec3 base, vec3 blend, float opacity){\n\
                return (blendSoftLight(base, blend) * opacity + base * (1.0 - opacity));\n\
            }'
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/uniform vec4 u_initialColor;/g, str);
        baseFragmentShaderSource.sources[0] = fragmentShader;   

        var mainstr = '\n\
            // Get map image\n\
            //vec4 texMapColor = texture2D(textureToSample, v_textureCoordinates);\n\
            vec4 texMapColor = computeDayColor(u_initialColor, clamp(v_textureCoordinates, 0.0, 1.0));\n\
            \n\
            // Convert to greyscale using NTSC weightings \n\
            float grey = dot(texMapColor.xyz, vec3(0.30, 0.59, 0.11));\n\
            vec3 greyColor = vec3(grey);\n\
            \n\
            \n\
            // 第一层叠加: 颜色加深，color(#084666), opacity(80%)\n\
            vec3 blendColor = vec3(8.0/255.0, 70.0/255.0, 102.0/255.0);\n\
            vec3 finalColor3 = blendColorBurn(greyColor, blendColor, 0.8);\n\
            \n\
            // 第二层叠加：柔光，color(##0D66B7), opacity(100%)\n\
            blendColor = vec3(13.0/255.0, 102.0/255.0, 183.0/255.0);\n\
            finalColor3 = blendSoftLight(finalColor3, blendColor, 1.0);\n\
            \n\
            // 第三层叠加：柔光，color(##000000), opacity(80%)\n\
            blendColor = vec3(0.0, 0.0, 0.0);\n\
            finalColor3 = blendSoftLight(finalColor3, blendColor, 0.8);\n\
            vec4 finalColor = vec4(finalColor3, 1.0);\n\
            //2 finalColor = texMapColor;\n\
            \n\
        ';
        fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, mainstr);
        this.invertFlag = true;    
    }
    else if(type == 4){
        //锐化
        var str='\n\
            #ifdef GL_FRAGMENT_PRECISION_HIGH\n\
              precision highp float;\n\
            #else\n\
              precision mediump float;\n\
            #endif\n\
              uniform vec4 u_initialColor;\n\
              //uniform sampler2D u_Sampler;\n\
              vec2 v_TexCoord;\n\
              \n\
              /*==============================================overlay===================================================*/\n\
            float blendOverlay(float base, float blend){\n\
                return base<0.5?(2.0*base*blend):(1.0-2.0*(1.0-base)*(1.0-blend));\n\
            }\n\
              \n\
            vec3 blendOverlay(vec3 base, vec3 blend){\n\
                return vec3(blendOverlay(base.r,blend.r),blendOverlay(base.g,blend.g),blendOverlay(base.b,blend.b));\n\
            }\n\
            /*==============================================overlay===================================================*/\n\
            \n\
            /*==============================================Lighten===================================================*/\n\
            float blendLighten(float base, float blend){\n\
                return max(blend,base);\n\
            }\n\
            \n\
            vec3 blendLighten(vec3 base, vec3 blend) {\n\
                return vec3(blendLighten(base.r,blend.r),blendLighten(base.g,blend.g),blendLighten(base.b,blend.b));\n\
            }';
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/uniform vec4 u_initialColor;/g, str);
        baseFragmentShaderSource.sources[0] = fragmentShader;  
        var mainstr = '\n\
            // 文字颜色 \n\
            vec3 overlayColor1 = vec3(0.619661, 0.937255, 1.0);\n\
            overlayColor1 = vec3(1.0, 1.0, 1.0);\n\
            //overlayColor1 = vec3(0.568627, 0.564705, 0.552941);\n\
            \n\
            // 地图叠加颜色 \n\
            vec3 overlayColor = vec3(0.101961, 0.329412, 0.360784);\n\
            \n\
            \n\
            /*============================================== 边缘检测 或 锐化 ===================================================*/\n\
            \n\
            // 上下左右纹理采样偏移亮，保持纹理大小的倒数 \n\
            const float offset = 1.0 / 256.0;  \n\
            \n\
            vec2 offsets[9];\n\
            offsets[0] = vec2(-offset, offset);  \n\
            offsets[0] = vec2(0.0,    offset);  \n\
            offsets[0] = vec2(offset,  offset);  \n\
            offsets[0] = vec2(-offset, 0.0);    \n\
            offsets[0] = vec2(0.0,    0.0);    \n\
            offsets[0] = vec2(offset,  0.0);    \n\
            offsets[0] = vec2(-offset, -offset); \n\
            offsets[0] = vec2(0.0,    -offset); \n\
            offsets[0] = vec2(offset,  -offset); \n\
            \n\
            // 锐化内核 \n\
            float kernel[9];  \n\
            kernel[0] = -1.0; \n\
            kernel[1] = -1.0; \n\
            kernel[2] = -1.0; \n\
            kernel[3] = -1.0; \n\
            kernel[4] = 9.0;  \n\
            kernel[5] = -1.0; \n\
            kernel[6] = -1.0; \n\
            kernel[7] = -1.0; \n\
            kernel[8] = -1.0;  \n\
            \n\
            \n\
            /*\n\
            // 边缘检测内核 \n\
            float kernel[9];  \n\
            kernel[0] = 1.0; \n\
            kernel[1] = 1.0; \n\
            kernel[2] = 1.0; \n\
            kernel[3] = 1.0; \n\
            kernel[4] = -8.0;  \n\
            kernel[5] = 1.0; \n\
            kernel[6] = 1.0; \n\
            kernel[7] = 1.0; \n\
            kernel[8] = 1.0;  \n\
            */\n\
            \n\
            \n\
            vec3 sampleTex[9];\n\
            v_TexCoord[0] = v_textureCoordinates[0];\n\
            v_TexCoord[1] = v_textureCoordinates[1];\n\
            for(int i = 0; i < 9; i++)\n\
            {\n\
              //sampleTex[i] = vec3(texture2D(u_Sampler, v_TexCoord + offsets[i]));\n\
              //vec4 texMapColor = computeDayColor(u_initialColor, clamp(v_textureCoordinates, 0.0, 1.0));\n\
              sampleTex[i] = vec3(texture2D(u_dayTextures[0], vec2(v_textureCoordinates.x,v_textureCoordinates.y) + offsets[i]));\n\
              vec3 atest = vec3(vec2(v_textureCoordinates.x,v_textureCoordinates.y) + offsets[i],v_textureCoordinates.z);\n\
              vec4 texMapColor = computeDayColor(u_initialColor, clamp(atest, 0.0, 1.0));\n\
              sampleTex[i] = texMapColor.xyz;\n\
            }\n\
             vec3 col;\n\
            for(int i = 0; i < 9; i++)\n\
                col += sampleTex[i] * kernel[i];\n\
            /*============================================== 下面是边缘检测 或 锐化后进行处理 ===================================================*/\n\
            \n\
            float avr_blend = 0.2126 * col.r + 0.7152 * col.g + 0.0722 * col.b; \n\
            avr_blend = 1.0 - avr_blend; \n\
            float scale = 0.1; //边缘检测后绘制颜色强度\n\
            vec3 blendColor = vec3(1.0-(1.0 - avr_blend)/scale);\n\
            \n\
            blendColor = blendOverlay(blendColor, overlayColor1);\n\
            /*============================================== 边缘检测 或 锐化。完成 ===================================================*/\n\
            \n\
            \n\
            \n\
            // 获取地图图片颜色 \n\
            //vec3 texColor = vec3(texture2D(u_dayTextures[0], v_TexCoord));\n\
            vec4 texMapColor = computeDayColor(u_initialColor, clamp(v_textureCoordinates, 0.0, 1.0));\n\
            vec3 texColor = texMapColor.xyz;\n\
            \n\
            // 反色、黑白 \n\
            vec3 invertColor = vec3(1.0) - texColor;\n\
            float average = 0.2126 * invertColor.r + 0.7152 * invertColor.g + 0.0722 * invertColor.b;\n\
            vec3 averageColor = vec3(average);\n\
            \n\
            // 叠加地图颜色 \n\
            vec3 baseColor = blendOverlay(averageColor, overlayColor);\n\
            \n\
            vec3 finalColor3= blendLighten(baseColor, blendColor);\n\;\n\
            vec4 finalColor = vec4(finalColor3,1.0);\n\
            ';
        fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, mainstr);
        this.invertFlag = true;    
    }
    else if(type == 5){
        //锐化
        var str='\n\
            #ifdef GL_FRAGMENT_PRECISION_HIGH\n\
              precision highp float;\n\
            #else\n\
              precision mediump float;\n\
            #endif\n\
              uniform vec4 u_initialColor;\n\
              //uniform sampler2D u_Sampler;\n\
              vec2 v_TexCoord;\n\
              \n\
              /*==============================================overlay===================================================*/\n\
            float blendOverlay(float base, float blend){\n\
                return base<0.5?(2.0*base*blend):(1.0-2.0*(1.0-base)*(1.0-blend));\n\
            }\n\
              \n\
            vec3 blendOverlay(vec3 base, vec3 blend){\n\
                return vec3(blendOverlay(base.r,blend.r),blendOverlay(base.g,blend.g),blendOverlay(base.b,blend.b));\n\
            }\n\
            /*==============================================overlay===================================================*/\n\
            \n\
            /*==============================================Lighten===================================================*/\n\
            float blendLighten(float base, float blend){\n\
                return max(blend,base);\n\
            }\n\
            \n\
            vec3 blendLighten(vec3 base, vec3 blend) {\n\
                return vec3(blendLighten(base.r,blend.r),blendLighten(base.g,blend.g),blendLighten(base.b,blend.b));\n\
            }';
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/uniform vec4 u_initialColor;/g, str);
        baseFragmentShaderSource.sources[0] = fragmentShader;  
        var mainstr = '\n\
            // 文字颜色 \n\
            vec3 overlayColor1 = vec3(0.619661, 0.937255, 1.0);\n\
            overlayColor1 = vec3(1.0, 1.0, 1.0);\n\
            \n\
            // 地图叠加颜色 \n\
            vec3 overlayColor = vec3(0.101961, 0.329412, 0.360784);\n\
            \n\
            \n\
            /*============================================== 边缘检测 或 锐化 ===================================================*/\n\
            \n\
            // 上下左右纹理采样偏移亮，保持纹理大小的倒数 \n\
            const float offset = 1.0 / 256.0;  \n\
            \n\
            vec2 offsets[9];\n\
            offsets[0] = vec2(-offset, offset);  \n\
            offsets[0] = vec2(0.0,    offset);  \n\
            offsets[0] = vec2(offset,  offset);  \n\
            offsets[0] = vec2(-offset, 0.0);    \n\
            offsets[0] = vec2(0.0,    0.0);    \n\
            offsets[0] = vec2(offset,  0.0);    \n\
            offsets[0] = vec2(-offset, -offset); \n\
            offsets[0] = vec2(0.0,    -offset); \n\
            offsets[0] = vec2(offset,  -offset); \n\
            \n\
            // 锐化内核 \n\
            float kernel[9];  \n\
            kernel[0] = -1.0; \n\
            kernel[1] = -1.0; \n\
            kernel[2] = -1.0; \n\
            kernel[3] = -1.0; \n\
            kernel[4] = 9.0;  \n\
            kernel[5] = -1.0; \n\
            kernel[6] = -1.0; \n\
            kernel[7] = -1.0; \n\
            kernel[8] = -1.0;  \n\
            \n\
            \n\
            /*\n\
            // 边缘检测内核 \n\
            float kernel[9];  \n\
            kernel[0] = 1.0; \n\
            kernel[1] = 1.0; \n\
            kernel[2] = 1.0; \n\
            kernel[3] = 1.0; \n\
            kernel[4] = -8.0;  \n\
            kernel[5] = 1.0; \n\
            kernel[6] = 1.0; \n\
            kernel[7] = 1.0; \n\
            kernel[8] = 1.0;  \n\
            */\n\
            \n\
            \n\
            vec3 sampleTex[9];\n\
            for(int i = 0; i < 9; i++)\n\
            {\n\
              //sampleTex[i] = vec3(texture2D(u_Sampler, v_TexCoord + offsets[i]));\n\
              //vec4 texMapColor = computeDayColor(u_initialColor, clamp(v_textureCoordinates, 0.0, 1.0));\n\
              //sampleTex[i] = vec3(texture2D(u_dayTextures[0], vec2(v_textureCoordinates.x,v_textureCoordinates.y) + offsets[i]));\n\
              vec3 atest = vec3(vec2(v_textureCoordinates.x,v_textureCoordinates.y) + offsets[i],v_textureCoordinates.z);\n\
              vec4 texMapColor = computeDayColor(u_initialColor, clamp(atest, 0.0, 1.0));\n\
              sampleTex[i] = texMapColor.xyz;\n\
            }\n\
             vec3 col;\n\
            for(int i = 0; i < 9; i++)\n\
                col += sampleTex[i] * kernel[i];\n\
            /*============================================== 下面是边缘检测 或 锐化后进行处理 ===================================================*/\n\
            \n\
            float avr_blend = 0.2126 * col.r + 0.7152 * col.g + 0.0722 * col.b; \n\
            avr_blend = 1.0 - avr_blend; \n\
            float scale = 0.01; //边缘检测后绘制颜色强度\n\
            vec3 blendColor = vec3(1.0-(1.0 - avr_blend)/scale);\n\
            \n\
            blendColor = blendOverlay(blendColor, overlayColor1);\n\
            /*============================================== 边缘检测 或 锐化。完成 ===================================================*/\n\
            \n\
            \n\
            \n\
            // 获取地图图片颜色 \n\
            //vec3 texColor = vec3(texture2D(u_dayTextures[0], v_TexCoord));\n\
            vec4 texMapColor = computeDayColor(u_initialColor, clamp(v_textureCoordinates, 0.0, 1.0));\n\
            vec3 texColor = texMapColor.xyz;\n\
            \n\
            // 反色、黑白 \n\
            vec3 invertColor = vec3(1.0) - texColor;\n\
            float average = 0.2126 * invertColor.r + 0.7152 * invertColor.g + 0.0722 * invertColor.b;\n\
            vec3 averageColor = vec3(average);\n\
            \n\
            // 叠加地图颜色 \n\
            vec3 baseColor = blendOverlay(averageColor, overlayColor);\n\
            \n\
            vec3 finalColor3 = blendLighten(baseColor, blendColor);\n\;\n\
            vec4 finalColor = vec4(finalColor3,1.0);\n\
            ';
        fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, mainstr);
        this.invertFlag = true;    
    }else if(type==6){
        // 黑色地图偏蓝
        var str = `float gray = 0.3 * color.r + 0.59 * color.g + 0.11 * color.b;
        vec4 finalColor = vec4(gray*vec3(0.6,1.0,1.4), color.a)`;
        var fragmentShader = baseFragmentShaderSource.sources[0].replace(/vec4 finalColor = color/g, str);
        this.invertFlag = true;    
    } 
    baseFragmentShaderSource.sources[0] = fragmentShader;
};

/**
 * 更新地图的操作状态：drawLine|drawMarkLine|drawCircle|drawPolygon|move|draw
 * drawMarkLine:只绘线不搜索
 * 
 * custom_cursor:保存move，tilt，point，choose-line choose-polygon choose-rectangle choose-circled的样式
 * optState：当前的鼠标状态
 *           move 默认状态,开始进入地球的默认状态，只有刚开始时用optstate保存
 *           tilt 临时状态，没有用optstate保存该状态
 *           point 临时状态，没有用optstate保存
 *           choose-line choose-polygon choose-rectangle choose-circle draw draw-line使用optstate保存状态
 * 规则：move、tilt进行地图平移和旋转时，可以进行要素的pick，但在choose和draw操作时则disable
 * 考虑：在选择（choose—*）操作时，需要平移或者倾斜旋转地图，但又需要保留当前状态，因此光标的修改和操作状态不是完全等同！
 */
vtron.comp.std.map.Cesium.prototype.changeState = function(name) {
    //如果在未完成选择操作以前就切换状态，则先删除
    //this.optChooseResult=false 表示上次的选择结果为空
    if((this.optVertices && this.optVertices.length>0) && (this.optChooseResult == false)&&this.optState!='draw'){
        this.layerDelete(this.optState,this.optID);
    }
    this.optState = name;
    this.optVertices = [];
    this.optRadius = 0;
    this.optID = vtron.util.createUUID();
    this.optChooseResult = false;
    // 禁止相机默认的事件
    //this._viewer.scene.screenSpaceCameraController.enableRotate = false;

    //修改光标样式
    this.changeCursor(name)
};

/*
 * 删除当前绘制的临时性的线、面和圈
 */
vtron.comp.std.map.Cesium.prototype.deleteTmpChooseGeomtry = function() {
    if((this.optVertices && this.optVertices.length>0) && (this.optChooseResult == false)){
        this.layerDelete(this.optState,this.optID);
        this.optVertices = [];
    }
};

/**
 * 经纬度(地理坐标WGS84)转世界坐标
 */
vtron.comp.std.map.Cesium.prototype.getCartesianFromCartographic = function(lon, lat) {
    if(!this._viewer) return;
    var cartesian3 = Cesium.Cartesian3.fromDegrees(lon, lat);
    return cartesian3;
};

/**
 * 世界坐标转经纬度(地理坐标WGS84)
 */
vtron.comp.std.map.Cesium.prototype.getCartographicFromCartesian = function(x, y, z) {
    if(!this._viewer) return;
    var ellipsoid = this._viewer.scene.globe.ellipsoid;
    var cartesian3 = new Cesium.Cartesian3(x, y, z);
    var cartographic = ellipsoid.cartesianToCartographic(cartesian3);
    var lon = Cesium.Math.toDegrees(cartographic.longitude);
    var lat = Cesium.Math.toDegrees(cartographic.latitude);
    return {lon: lon, lat: lat};
};

/**
 * 经纬度(地理坐标WGS84)转屏幕坐标
 */
vtron.comp.std.map.Cesium.prototype.getScreenCoordFromCartographic = function(lon, lat) {
    if(!this._viewer) return;
    var cartesian = Cesium.Cartesian3.fromDegrees(lon, lat);
    var screenCoord = Cesium.SceneTransforms.wgs84ToWindowCoordinates(this._viewer.scene, cartesian);
    if(!screenCoord) return null;
    return {x: parseInt(screenCoord.x), y: parseInt(screenCoord.y)};
};

/**
 * 屏幕坐标转经纬度(地理坐标WGS84)，兼容mapEngine
 * 屏幕坐标 => 世界坐标 => 经纬度
 */
vtron.comp.std.map.Cesium.prototype.getCartographicFromScreenCoord = function(screenX, screenY) {
    if(!this._viewer) return;
    // 借助场景拾取原理计算世界坐标
    var pick = new Cesium.Cartesian2(screenX, screenY);
    var cartesian = this._viewer.camera.pickEllipsoid(pick);
    if(cartesian==undefined) 
        return cartesian;
    return this.getCartographicFromCartesian(cartesian.x, cartesian.y, cartesian.z);
};

/**
 * 等级转换成高度，兼容mapEngine
 */
vtron.comp.std.map.Cesium.prototype.levelConvertToHeight = function(level) {
    var z = (42000 - level * 5000);
    if (z <= 0) z = 2000;
    return z;
};

/**
 * 获取当前层级，利用相机高度计算
 */
vtron.comp.std.map.Cesium.prototype.getLevel = function() {
    var height = this._viewer.camera.positionCartographic.height;
    var level = (42000 - height) / 5000;
    level = Math.min(Math.max(level, this.minLevel), this.maxLevel);
    return parseInt(level);
};

/**
 * 获取当前范围，兼容mapEngine
 */
vtron.comp.std.map.Cesium.prototype.getRegion = function() {
    // 此方法不适用camera倾斜,正确的方式应该是计算四个点,有待完善
    var rectangle = this._viewer.camera.computeViewRectangle();
    var left = Cesium.Math.toDegrees(rectangle.west),
        right = Cesium.Math.toDegrees(rectangle.east),
        top = Cesium.Math.toDegrees(rectangle.north),
        bottom = Cesium.Math.toDegrees(rectangle.south);
    return {left: left, right: right, top: top, bottom: bottom};
};

/**
 * 获取当前中心点，返回经纬度，兼容mapEngine
 */
vtron.comp.std.map.Cesium.prototype.getCenter = function() { 
    var halfWidth = this.canvasWidth * 0.5,
        halftHeight = this.canvasHeight * 0.5;
    var geoCoord = this.getCartographicFromScreenCoord(halfWidth, halftHeight);
    return geoCoord;
};

/**
 * 设置相机的位置，用于同步相机平移的操作
 *  @param position 世界坐标
 *  @param heading,pitch,roll 弧度
 */
vtron.comp.std.map.Cesium.prototype.setCameraPosition = function(position, heading, pitch, roll, info="setCameraPosition", flightCompleteCallback,positionCartographic) {
    if(!this._viewer) return;
    flightCompleteCallback = flightCompleteCallback || function() {};
    this._cmdinfo = info;
    if(this._viewer.scene.mode != Cesium.SceneMode.SCENE2D){
        this._viewer.camera.flyTo({
            destination: new Cesium.Cartesian3(position.x, position.y, position.z),
            orientation: {
                heading: heading,
                pitch: pitch,
                roll: roll,
            },
            complete: flightCompleteCallback
        });
    }
    else{
        if(!positionCartographic) return;
        var lon = Cesium.Math.toDegrees(positionCartographic.longitude);
        var lat = Cesium.Math.toDegrees(positionCartographic.latitude);
        var h = positionCartographic.height;
        this._viewer.camera.flyTo({
            destination: new Cesium.Cartesian3.fromDegrees(lon,lat,h),
            orientation: {
                heading: heading,
                pitch: pitch,
                roll: roll,
            },
            complete: flightCompleteCallback
        });
    }

};

/**
 * 获取当前相机位置
 */
vtron.comp.std.map.Cesium.prototype.getCameraPosition = function() {
    let detail = {};
    detail.position = this._viewer.camera.position;
    detail.heading = this._viewer.camera.heading;
    detail.pitch = this._viewer.camera.pitch;
    detail.roll = this._viewer.camera.roll;
    detail.geoCoord = this.getCartographicFromCartesian(detail.position.x, detail.position.y, detail.position.z); 
    detail.pitchDegree = Cesium.Math.toDegrees(detail.pitch);
    detail.positionCartographic = this._viewer.camera.positionCartographic;
    return vtron.util.clone(detail);
};

/**
 *  移动地图中心点 地理坐标
 *  @param x 地理坐标X
 *  @param y 地理坐标Y
 *  @param level level不传入，只移动中心点
 */
vtron.comp.std.map.Cesium.prototype.moveCenter = function(x, y, level, duration = 1, flightCompleteCallback) {
    var z = this.levelConvertToHeight(level || this.getLevel());
    var heading = Cesium.Math.toRadians(0.0),
        pitch = Cesium.Math.toRadians(-this.pitch),
        range = z;
    this._viewer.camera.cmdormouse = 'cmd';
    var headingPitchRange = new Cesium.HeadingPitchRange(heading, pitch, range);
    flightCompleteCallback = flightCompleteCallback || function() {};
    var boundingSphere = {'center': Cesium.Cartesian3.fromDegrees(x, y), 'radius': 0};
    this._viewer.camera.flyToBoundingSphere(boundingSphere, {
        duration: duration,
        offset: headingPitchRange,
        complete: flightCompleteCallback
    });
};

/**
 * 设置相机
 *  @param x 地理坐标X
 *  @param y 地理坐标Y
 *  @param pitch 俯仰角度
 *  @param height 相机高度
 */
vtron.comp.std.map.Cesium.prototype.setCameraPositionByBoundingSphere = function(x, y, height, pitch,  duration = 3, flightCompleteCallback) {
    var heading = Cesium.Math.toRadians(0.0),
        pitch = Cesium.Math.toRadians(-pitch),
        range = height || this._viewer.camera.positionCartographic.height;
    var headingPitchRange = new Cesium.HeadingPitchRange(heading, pitch, range);
    flightCompleteCallback = flightCompleteCallback || function() {};
    var boundingSphere = {'center': Cesium.Cartesian3.fromDegrees(x, y), 'radius': 0};
    this._viewer.camera.flyToBoundingSphere(boundingSphere, {
        duration: duration,
        offset: headingPitchRange,
        complete: flightCompleteCallback
    });
};


/**
 *  地图重置为初始位置
 */
vtron.comp.std.map.Cesium.prototype.moveReset = function() {
    if(!this.defaultCamera)
        this.moveCenter(parseFloat(this.cenX), parseFloat(this.cenY), parseInt(this.level));
    else{
        //默认相机参数,JSON字符串'{"x":,"y":,"z":,"heading":,"pitch":,"roll":}'
        var cameraparm = this.defaultCamera;
        var parmObject = JSON.parse(cameraparm);
        var position = {
                x: parmObject.x,
                y: parmObject.y,
                z: parmObject.z
            },
            heading = parmObject.heading;
            pitch = parmObject.pitch;
            roll = parmObject.roll;
        this.setCameraPosition(position, heading, pitch, roll);
    }
};

/**
 *  地图缩放
 */
vtron.comp.std.map.Cesium.prototype.zoom = function(level) {
    var height = this.levelConvertToHeight(level);
    this._viewer.camera.zoomIn(height);
};

/**
 *  地图放大
 */
vtron.comp.std.map.Cesium.prototype.zoomIn = function() {
    var level = this.getLevel() + 1;
    var height = this.levelConvertToHeight(level);
    this._viewer.camera.zoomIn(height);
};

/**
 *  地图缩小
 */
vtron.comp.std.map.Cesium.prototype.zoomOut = function() {
    var level = this.getLevel() - 1;
    var height = this.levelConvertToHeight(level);
    this._viewer.camera.zoomOut(height);
};

/**
 * 地球自转更新相机的回调
 */
vtron.comp.std.map.Cesium.prototype.icrf = function(scene, time) {
    if (scene.mode !== Cesium.SceneMode.SCENE3D) {
        return;
    }
    var icrfToFixed = Cesium.Transforms.computeIcrfToFixedMatrix(time);
    if (Cesium.defined(icrfToFixed)) {
        var offset = Cesium.Cartesian3.clone(scene.camera.position);
        var transform = Cesium.Matrix4.fromRotationTranslation(icrfToFixed);
        scene.camera.lookAtTransform(transform, offset);
    }
};

/**
 * 热力图初始化，具体参数详见CesiumHeatmap.js
 * bounds = {
 * 		west, east, south, north
 * }
 * options = {
 * 	 radius: 5,
 * 	 maxOpacity: 1.0,
 * 	 minOpacity: 0.2,
 * 	 blur: 0.8,
 * 	 gradient: {
 * 	   '0': 'rgb(0, 255, 0)',
 * 	   '0.5': 'rgb(255, 255, 0)',
 * 	   '1.0': 'rgb(255, 0, 0)'
 * 	 }
 * }
 */
vtron.comp.std.map.Cesium.prototype.initHeatmap = function(bounds, options) {
	if(this.heatmap) return;
	this.heatmap = CesiumHeatmap.create(this._viewer, bounds, options);
};

vtron.comp.std.map.Cesium.prototype.initHeatmap_webgl = function(bounds, options) {
    if(this.heatmap) return;
    this.heatmap = CesiumHeatmap_webgl.create(this._viewer, bounds, options);
};

/**
 *  更新热力图
 *  dataInfo = [{ x:lon, y:lat, value }]
 */
vtron.comp.std.map.Cesium.prototype.updateHeatmapData = function(min, max, dataInfo) {
	if(this.heatmap) {
		this.heatmap.setWGS84Data(min, max, dataInfo);
	}
};

vtron.comp.std.map.Cesium.prototype.updateHeatmapData_webgl = function(min, max, dataInfo) {
    if(this.heatmap) {
        this.heatmap.setWGS84Data(min, max, dataInfo);
    }
};

/**
 *  显示热力图
 *  应该合并到showLayer
 */
vtron.comp.std.map.Cesium.prototype.heatmapLayerShow = function() {
	if(this.heatmap) {
		this.heatmap.show(true);
	}
};

vtron.comp.std.map.Cesium.prototype.heatmapLayerShow_webgl = function() {
    if(this.heatmap) {
        this.heatmap.show(true);
    }
};

/**
 *  隐藏热力图
 */
vtron.comp.std.map.Cesium.prototype.heatmapLayerHide = function() {
	if(this.heatmap) {
		this.heatmap.show(false);
	}
};

/**
 *  清空热力图
 */
vtron.comp.std.map.Cesium.prototype.heatmapLayerClear = function(){
    if(this.heatmap){
        this.heatmap.clear();
    }
}
/**
 * 地球自转效果
 */
vtron.comp.std.map.Cesium.prototype.globeRotation = function() {
    if(this._globeRotation) return;
    this._globeRotation = true;
    this._viewer.camera.flyHome(0);
    this._viewer.clock.multiplier = 24 * 60;//一分钟自转一次
    this._viewer.clock.shouldAnimate = true;
    this._viewer.scene.postUpdate.addEventListener(this.icrf);
};

/**
 * 取消自转效果
 */
vtron.comp.std.map.Cesium.prototype.cancelGlobeRotation = function() {
    this._globeRotation = false;
    this._viewer.clock.multiplier = 1;
    this._viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
    this._viewer.scene.postUpdate.removeEventListener(this.icrf);
};

/**
 * 等待地图初始化完成
 */
vtron.comp.std.map.Cesium.prototype.waitMapInit = function(callback,time) {
  var _this = this;
  time = time || 500;
  var func = function(){
    if(!_this._viewer){
      setTimeout(func, time);
    } else {
      if(typeof(callback) == "function"){
        callback.call(_this);
      }
    }
  }
  func();
};

/*
 * 等待图层创建完成
 */
vtron.comp.std.map.Cesium.prototype.waitLayer = function(layerName,callback,time) {
  var _this = this;
  time = time || 500;
  var func = function(){
    var datasource = _this.getDataSourceByName(layerName);
    if(!datasource) {
      setTimeout(func, time);
    } else {
      if(typeof(callback) == "function"){
        callback.call(_this);
      }
    }      
  }
  func();
};

/*
*  添加聚合图
*  style:数组，每个值代表聚合图分多少类（50+,100+...）,每类的图标颜色
*  [
*      {
*          name：'10',
*          value:10,
*          bgcolor:'rgba(255, 0, 0, 1)',
*          width:80
*      },
*      {
*          name：'100',
*          value:100,
*          bgcolor:'rgba(100, 20, 0, 1)',
*          width:120
*      },
*  ]
*  
 */

vtron.comp.std.map.Cesium.prototype.addclusterLayer = function(layerName, dataInfo, imageUrl="", style="",pixelRange=0.12,minimumClusterSize=3,scale = 1, height = 0, bShowLayer = true, supportSearch = false) {
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        supportSearch && this.searchLayerArray.push(layerName);
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);

        //设置聚合图属性
        var enabled = true;

        datasource.clustering.enabled = enabled;
        datasource.clustering.pixelRange = pixelRange;
        datasource.clustering.minimumClusterSize = minimumClusterSize;
        
        //每次重新计算的回调
        var removeListener;

        //将聚合图分类，每一类的pin样式
        var pinBuilder = new Cesium.PinBuilder();
        if(this.pinstyle == undefined){
            if(style==""){
                var pin500 = pinBuilder.fromText('500+', Cesium.Color.RED, 120).toDataURL();
                var pin300 = pinBuilder.fromText('300+', Cesium.Color.ORANGE, 120).toDataURL();
                var pin100 = pinBuilder.fromText('100+', Cesium.Color.YELLOW, 120).toDataURL();
                var pin50 = pinBuilder.fromText('50+', Cesium.Color.GREEN, 80).toDataURL();
                var pin10 = pinBuilder.fromText('10+', Cesium.Color.BLUE, 60).toDataURL();

                this.pinstyle = [];
                this.pinstyle.push({value:500,style:pin500});
                this.pinstyle.push({value:300,style:pin300});
                this.pinstyle.push({value:100,style:pin100});
                this.pinstyle.push({value:50,style:pin50});
                this.pinstyle.push({value:10,style:pin10});
            }
            else{
                if(!(style instanceof Array)) style = [style];
                style.forEach((data) => {
                    if(this.pinstyle==undefined) this.pinstyle = [];
                    //this.pinstyle[data.value.toString()] = pinBuilder.fromText(data.value.toString()+'+', Cesium.Color.fromCssColorString(data.bgcolor), data.width||80).toDataURL();;
                    this.pinstyle.push({value:data.value,style:pinBuilder.fromText(data.value.toString()+'+', Cesium.Color.fromCssColorString(data.bgcolor), data.width||80).toDataURL()});
                
                });
            }

            var compare = function (obj1, obj2) {
                var val1 = obj1.value;
                var val2 = obj2.value;
                if (val1 < val2) {
                    return 1;
                } else if (val1 > val2) {
                    return -1;
                } else {
                  return 0;
                }            
            } 
            this.pinstyle = this.pinstyle.sort(compare);
        }
        

        var singleDigitPins = new Array(8);
        for (var i = 0; i < singleDigitPins.length; ++i) {
            singleDigitPins[i] = pinBuilder.fromText('' + (i + 2), Cesium.Color.VIOLET, 48).toDataURL();
        }

        if(!datasource.customStyle){
            function customStyle(instacnce) {
                        if (Cesium.defined(removeListener)) {
                            removeListener();
                            removeListener = undefined;
                        } 
                        else {
                            var instance_view = instacnce;
                            removeListener = datasource.clustering.clusterEvent.addEventListener(function(clusteredEntities, cluster) {
                                // cluster.label.show = false;
                                cluster.billboard.show = true;
                                //cluster.billboard.id = cluster.label.id;
                                cluster.billboard.verticalOrigin = Cesium.VerticalOrigin.BOTTOM;

                                /*if (clusteredEntities.length >= 500) {
                                    cluster.billboard.image = pin500;
                                } else if (clusteredEntities.length >= 300) {
                                    cluster.billboard.image = pin300;
                                } else if (clusteredEntities.length >= 100) {
                                    cluster.billboard.image = pin100;
                                } else if (clusteredEntities.length >= 50) {
                                    cluster.billboard.image = pin50;
                                } else if (clusteredEntities.length >= 10) {
                                    cluster.billboard.image = pin10;
                                } else {
                                    cluster.billboard.image = singleDigitPins[clusteredEntities.length - 2];
                                }*/
                                var bfind = false;
                                for(var i=0;i<instance_view.pinstyle.length;i++){
                                    if(clusteredEntities.length>=instance_view.pinstyle[i].value){
                                        cluster.billboard.image = instance_view.pinstyle[i].style;
                                        bfind = true;
                                        break;
                                    }
                                }
                                if(bfind==false){
                                    cluster.billboard.image = singleDigitPins[clusteredEntities.length - 2];
                                }
                            });
                        }
                    }
                }
            customStyle(this);
        }
       
    //聚合图中添加点
    if(!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        if(data.x&&data.y){
            var position = Cesium.Cartesian3.fromDegrees(data.x, data.y, height);
            var entity = datasource.entities.getById(data.id);
            if(entity){
                //先只更新坐标和图片
                entity.position=position;
                entity.billboard.image = imageUrl;
            }
            else{
                entity = datasource.entities.add({
                    id: data.id,
                    name:layerName,
                    position: position,
                    billboard: {
                        image : data.imageUrl||imageUrl,
                        scale: this.imageScaleFactor * scale,
                        verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                        //scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                        //distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0.0, 100000)
                    }
                });        
            }
        }
        else{
            var entity = datasource.entities.getById(data.id);
            entity = datasource.entities.add({
                    id: data.id,
                    name:layerName,
            });       
        }
    });
};

/*
 * 清空聚合图
*/
vtron.comp.std.map.Cesium.prototype.clearclusterLayer = function(layerName) {
var datasource = this.getDataSourceByName(layerName);
    if(datasource) {
        datasource.clustering.enabled = false;
        this._viewer.dataSources.remove(datasource, true);
    }
};

/*
 *获取圆的外包
 *data{
 *   tyle:'circle',
 *   GeoCenter:{x,y,z,lon,lat}, //世界坐标:xyz,经纬度坐标是lon,lat
 *   GeoRadius:  //米
 *}
 */
vtron.comp.std.map.Cesium.prototype.envelope = function(data) {
    if(data) {
        var type = data.type;
        if(type=='circle'){
            //世界坐标转经纬度
            var lonlat={};
            if(!data.GeoCenter.lon || !data.GeoCenter.lat){
                lonlat = this.getCartographicFromCartesian(data.GeoCenter.x,data.GeoCenter.y,data.GeoCenter.z);
            }
            else{
                lonlat.lon = data.GeoCenter.lon;
                lonlat.lat = data.GeoCenter.lat;
            }
            //方法1：中心点的世界坐标转经纬度，再转墨卡托，然后计算外包，再转经纬度？ 这种方法得到的box不能包住圆，是计算出问题还是圆显示有问题误差！！！
            //墨卡托的n米在实际中达不到n米
            //经纬度转wm
            var wm = this.wgs84ToMercator({x:lonlat.lon,y:lonlat.lat});
            //计算envelope
            var minx = wm.x-data.GeoRadius;
            var maxx = wm.x+data.GeoRadius;
            var miny = wm.y-data.GeoRadius;
            var maxy = wm.y+data.GeoRadius;
            var envelope = this.mercatorToWgs84BB({north:maxy,east:maxx,south:miny,west:minx});
            //方法2：使用turf计算点的缓冲区，计算缓冲区的envelop
            // var point = turf.point([lonlat.lon,lonlat.lat]);
            // var buffer = turf.buffer(point,data.GeoRadius/1000,{units:'kilometers'});
            // var bbox = turf.bbox(buffer);
            // envelope.west = bbox[0];
            // envelope.south = bbox[1];
            // envelope.east = bbox[2];
            // envelope.north = bbox[3];
            // var dis = turf.distance(t,point1,{units:'kilometers'});

            //cesium本身的方式获取到的距离是正确的
            // var geodesic = new Cesium.EllipsoidGeodesic();
            // var endCartographic = Cesium.Cartographic.fromDegrees(this._viewer.lonmax,this._viewer.latmin);;
            // var startCartographic = Cesium.Cartographic.fromDegrees(this._viewer.lonmin,this._viewer.latmin);
            // geodesic.setEndPoints(startCartographic, endCartographic);

            // geodesic.setEndPoints(Cesium.Cartographic.fromDegrees(0,0), Cesium.Cartographic.fromDegrees(0,1));
            // var t =geodesic.surfaceDistance;


            return envelope;
        }
    }
};

/*  Convert a WGS84 location into a mercator location
 *
 *  p: the WGS84 location like {x: lon, y: lat}
*/
vtron.comp.std.map.Cesium.prototype.wgs84ToMercator = function(p) {
    if(this.WMP==undefined) {
        this.WMP = new Cesium.WebMercatorProjection();
    }
    var mp = this.WMP.project(Cesium.Cartographic.fromDegrees(p.x, p.y));
    return {
        x: mp.x,
        y: mp.y
    };
};

/*  Convert a mercator location into a WGS84 location
 *
 *  p: the mercator lcation like {x, y}
*/
vtron.comp.std.map.Cesium.prototype.mercatorToWgs84 = function(p) {
    if(this.WMP==undefined){
        this.WMP = new Cesium.WebMercatorProjection();
    }
    var wp = this.WMP.unproject(new Cesium.Cartesian3(p.x, p.y));
    return {
        x: wp.longitude,
        y: wp.latitude
    };
};

/*  Convert a mercator bounding box into a WGS84 bounding box
 *
 *  bb: the mercator bounding box like {north, east, south, west}
*/
vtron.comp.std.map.Cesium.prototype.mercatorToWgs84BB = function(bb) {
    if(this.WMP==undefined){
        this.WMP = new Cesium.WebMercatorProjection();
    }
    var sw = this.WMP.unproject(new Cesium.Cartesian3(bb.west, bb.south));
    var ne = this.WMP.unproject(new Cesium.Cartesian3(bb.east, bb.north));
    return {
        north: this.rad2deg(ne.latitude),
        east: this.rad2deg(ne.longitude),
        south: this.rad2deg(sw.latitude),
        west: this.rad2deg(sw.longitude)
    };
};

/*
 *按照四边形区域显示地图
 */
vtron.comp.std.map.Cesium.prototype.flytoRectangle = function(bbox){
    if(!this._viewer) return;
    var rectangle = Cesium.Rectangle.fromDegrees(bbox.west, bbox.south, bbox.east, bbox.north);
    this._viewer.camera.flyTo({
        destination : rectangle
    });
};

/*  Convert degrees into radians
 *
 *  d: the degrees to be converted to radians
*/
vtron.comp.std.map.Cesium.prototype.deg2rad = function(d) {
    var r = d * (Math.PI / 180.0);
    return r;
};
        
/*  Convert radians into degrees
*
*  r: the radians to be converted to degrees 
*/
vtron.comp.std.map.Cesium.prototype.rad2deg = function(r) {
    var d = r / (Math.PI / 180.0);
    return d;
};

/*
   添加文字标注
   layername 图层名  （往地图中添加任何的要素都需要提供图层名和id，这样方便使用方控制进行添加删除显示隐藏等）
   dataInfo: [
       {
           id:
           name:
           text:
           font:
           textcolor:
            textposition:{lon:,lat}
            verticalOrigin:
            textbackgroundImage:{url:,width:,height:}
       }
   ]
 */
vtron.comp.std.map.Cesium.prototype.addLabelElement = function(layerName,dataInfo){
if(!layerName) layerName = 'tempLayer';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        //supportSearch && this.searchLayerArray.push(layerName);
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }
    if(!dataInfo) return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    dataInfo.forEach((data) => {
        var tposition = Cesium.Cartesian3.fromDegrees(data.textposition.lon, data.textposition.lat, data.textposition.height||0);
        var entity = datasource.entities.getById(data.id);
        if(entity){
            //先只更新label的属性
            //entity.billboard.image = imageUrl;
        }
        else{
            entity = datasource.entities.add({
                id: data.id,
                name:layerName,
                position : tposition,
                billboard : {
                            image : data.textbackgroundImage.url,//"/test-map-engine/image/shui.png", // default: undefined
                            show : true, // default
                            width : data.textbackgroundImage.width,//100, // default: undefined
                            height : data.textbackgroundImage.height,//100, // default: undefined
                            verticalOrigin : Cesium.VerticalOrigin.BOTTOM
                },
                label : {
                            text : data.text,//'60',
                            font : data.font,//'30px sans-serif',
                            fillColor : Cesium.Color.fromCssColorString(data.textcolor),//Cesium.Color.WHITE,
                            style: Cesium.LabelStyle.FILL,
                            //outlineWidth : 2,
                            verticalOrigin : Cesium.VerticalOrigin.BOTTOM,
                            pixelOffset : new Cesium.Cartesian2(0, data.textbackgroundImage.height*-1/2),
                            showBackground:true,
                            backgroundColor:data.textcolor
                }
            });        
        }   
    });
};

/*
 *控制地图移动旋转倾斜的开关
 */
vtron.comp.std.map.Cesium.prototype.enableMap = function(enable){
    this._viewer.scene.screenSpaceCameraController.enableRotate = enable;
    this._viewer.scene.screenSpaceCameraController.enableTranslate = enable;
    this._viewer.scene.screenSpaceCameraController.enableTilt  = enable;
    //this._viewer.scene.screenSpaceCameraController.enableZoom = enable;
};

/*
 *控制地图缩放的开发
 */
vtron.comp.std.map.Cesium.prototype.enableMapZoom = function(enable){
    this._viewer.scene.screenSpaceCameraController.enableZoom = enable;
};

/*
 *指北针的旋转角度，顺时针
 */
vtron.comp.std.map.Cesium.prototype.compassAngle = function(){
    return this._viewer.compassangle;
};

/*
 *
 */
vtron.comp.std.map.Cesium.prototype.resetCompass = function(){
    var camera = this.getCameraPosition();
    camera.heading = Cesium.Math.toRadians(0);
    camera.pitch = Cesium.Math.toRadians(-90);
    camera.roll = Cesium.Math.toRadians(0);
    this.setCameraPosition(camera.position,camera.heading,camera.pitch,camera.roll);
};

/*
 *鼠标位置，选中的实体
 *type=0 返回最上层的一个实体
 *type=1 返回所有的实体
 *x y 屏幕坐标
 */
vtron.comp.std.map.Cesium.prototype.pick = function(x,y,type){
    var pickedobject;
    if(type==0){
        pickedobject = this._viewer.scene.pick(new Cesium.Cartesian2(x,y))
    }
    else if(type==1){
        pickedobject = this._viewer.scene.drillPick(new Cesium.Cartesian2(x,y))
    }
    return pickedobject;
};

/**
 * 添加静态点图层数据，数据源是GeoJson格式，其中参数name是选中节点后判断类型的依据,按照不同的属性配置不同的style
 * layerName：alert|gps|yiyuan, bShowLayer: 默认显示加载层
 * style
 * {
 *     
 *        value1:"imageurl1",//value1是属性值1
 *        value2:"imageurl2" //value2是属性值2
 *     
 * }
 */
vtron.comp.std.map.Cesium.prototype.loadPointLayerGeoJsonData_withAttribute = function(layerName, url, attributeName,style,bShowLayer = true, supportSearch = false) {
    this._dsLayer.url = url;
    supportSearch && this.searchLayerArray.push(layerName);
    this._dsLayer.load({
        success: (data) => {
            if(data.data && !data.data.length) return;
            var entitiesCollection = new Cesium.CustomDataSource(layerName);
            for(var i = 0, len = data.features.length; i < len; i++) {
                let id = data.features[i].id,
                    coord = data.features[i].geometry.coordinates,
                    properties = data.features[i].properties;
                var imageU = imageUrl;
                    if(style && style.properties[attributeName])
                        imageU = style.properties[attributeName];
                    position = Cesium.Cartesian3.fromDegrees(coord[0], coord[1], height),
                    entity = entitiesCollection.entities.add({
                        id: id,
                        name: layerName,
                        position: position,
                        billboard: {
                            image : imageU,
                            scale: this.imageScaleFactor * scale,
                            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                            //sizeInMeters : true,
                            scaleByDistance : new Cesium.NearFarScalar(1000, 0.5, 100000, 0.1),
                            //distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0.0, 200000),
                        }
                    });
                entity.show = bShowLayer;
                entity.layerName = layerName;
                entity.x = coord[0];
                entity.y = coord[1];
                entity.id = id;
                entity.otherProperty = properties;
            };
            this._viewer.dataSources.add(entitiesCollection);
        }
    })
};

/*
 *添加鼠标样式
 *curUrl:样式图片或者系统光标名
 *type：0：系统光标，1：自定义光标
 *left : 光标热点x
 *top ： 光标热点y 0，0 表示图片左上角
 *可以考虑建立cursor的缓存，避免每次请求图片
 */
vtron.comp.std.map.Cesium.prototype.addCursorStyle = function(curUrl,type=0,left=0,top=0,enable=true){
    //this.style.cursor = "pointer";
    //this.$$("canvas").style.cursor="w-resize";
    var cursorvalue;
    if(curUrl==""||curUrl==undefined){
        cursorvalue = 'default';
    }
    else{
        if(type!=0){
            cursorvalue = "url("+curUrl+")"+left+" "+ top+",auto";
        }
        else{
            cursorvalue = curUrl;
        } 
    }


    return cursorvalue;
};

/*
 * 改变光标的样式：改变光标样式，不影响当前地图的操作状态
 * 内部函数！
 * cursorStyle 参考custom_Cursor变量的赋值,比如"move","choose-line"......
 */
vtron.comp.std.map.Cesium.prototype.changeCursor = function(cursorStyle){
    if(this.custom_Cursor && this.custom_Cursor[cursorStyle]){
        this.$$("canvas").style.cursor = this.custom_Cursor[cursorStyle];
        this.cursorstyle = cursorStyle;
        //console.log(this.cursorstyle);
    }
};

/*
 *恢复光标样式和optstate，保持一致
 *内部函数！
 *目的：
 */
/*vtron.comp.std.map.Cesium.prototype.resetCursor = function(){
    if(this.custom_Cursor&&this.custom_Cursor[this.optState]){
        this.$$("canvas").style.cursor = this.custom_Cursor[this.optState];
        this.cursorstyle = this.optState;
    }
};*/

/*
 *鼠标移动到图层的某个要素时，要素改变显示样式
 */
vtron.comp.std.map.Cesium.prototype.pickedStyle = function(layerName,styleUrl){
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.datasources.add(datasource);
    }
    
    datasource.imagePicked =  styleUrl;
};

/*
 *修改被选中实体的样式以及提示信息，在mouse_move中调用
 *instance: cesium viewer
 *pickedObject: 鼠标选中的一批实体，目前只实现选中一个
 *change：
 *    0：恢复原来图标
 *    1：修改为被选中的图标
 *    //2：显示提示信息
 */
var changeObjectStyle = function(instance,pickedObject,change){

    if(change==1){
        //恢复obj的样式为dataSources.imageSrc 或者 entities.imageSrc
        for(var i=0;i<instance.pickedEntities.length;i++){
            var entity = instance.pickedEntities[i];
            var datasource = instance.getDataSourceByName(entity.layerName);
            if(entity.billboard)
                entity.billboard.image = entity.imageSrc||datasource.imageSrc;
            entity.picked_startTime = undefined;
        }
        instance.pickedEntities = [];

        //修改obj的样式为dataSources.imagePicked
        var entity = pickedObject.id;
        var datasource = instance.getDataSourceByName(entity.layerName);
        if(!datasource) return;
        if((entity.imagePicked||datasource.imagePicked||datasource.imageSrc)&&entity.billboard)
            entity.billboard.image = entity.imagePicked||datasource.imagePicked||datasource.imageSrc;//"http://sys01/test-map-engine/image/alert1.png";//
        instance.pickedEntities.push(entity);
        entity.picked_startTime = new Date().getTime();//被选中的时间
    }
    else if(change==0){
        if(instance.pickedEntities.length==0){
            return;
        }
        else{
            //恢复obj的样式为dataSources.imageSrc 或者 entities.imageSrc
            for(var i=0;i<instance.pickedEntities.length;i++){
                var entity = instance.pickedEntities[i];
                var datasource = instance.getDataSourceByName(entity.layerName);
                if(entity.billboard)
                    entity.billboard.image = entity.imageSrc||datasource.imageSrc;
                entity.picked_startTime = undefined;
            }
            instance.pickedEntities = [];
        }
    }
};

var setPickeObjectLabel = function(instance,label,display){
    var mapTag = instance.$$("#mapTag");
    var beshow = mapTag.style.display;
    var plable = mapTag.style.innerHTML;
    if(display=='block'&&( display!=beshow || plable!=label))
    {   
        //如果label需要显示，则更新坐标等信息
        var offset = 20;
        if(this.offsetWidth>4096) 
            offset = 64;
        var labelx = instance._mousex + offset/2;
        var labely = instance._mousey + offset;
        mapTag.innerHTML = label;
        mapTag.style.left= labelx+'px';
        mapTag.style.top= labely+'px';
        mapTag.style.display = display; 
    }
    else if(display == 'none' && display!=beshow)
    {   
        //如果label当前是显示状态，需要设置为隐藏
        mapTag.style.display = display; 
    } 
};

/*
 *处理鼠标mouse时，鼠标移动到点图层上的效果
 */
var _doPickedJob = function(instance){
    //创建定时器，每1S钟，处理标注的显示
    if(instance.timer_ShowLabel_ForPickedObject==undefined){
        //创建定时器10ms（模拟hover）,处理被选中的object的label
        window.setInterval(function(){
            _updateLabel(instance);
            },10);
        instance.timer_ShowLabel_ForPickedObject = true;
    }

    //处理鼠标位置下的实体
    //在非选择和绘制状态下,非旋转，进行pick
    if(instance._mousetype2 != 'RIGHT_DOWN+MOUSE_MOVE'
        &&instance._mousetype2 != 'LEFT_DOWN+MOUSE_MOVE'){
        if(instance.pickedEntities==undefined){
            instance.pickedEntities = [];//记录被选中的一个实体，可能以后会扩展为多个实体
        }

        var pickobject = instance.pick(instance._mousex,instance._mousey,0);
        if(pickobject){
            if(pickobject==instance.pickedEntities[0]) 
                return;
            //若在绘制进行时，则不改变光标
            if(instance.optState.indexOf('choose')>=0 || instance.optState.indexOf('draw')>=0){
                if(instance.optVertices.length>0){
                    return;
                }
            }
            //修改光标为pointer
            instance.changeCursor('point');
            //修改被选中的object图标
            changeObjectStyle(instance,pickobject,1);//true 修改
        }
        else{
            //复原光标
            instance.changeCursor(instance.optState);
            //被选中的object图标改为不被选中
            changeObjectStyle(instance,pickobject,0);//false 恢复默认图标
        }                   
    } 
}

/*
 *处理被选中图标的文字标注
 */
var _updateLabel = function(instance){
    if(!instance || !instance.pickedEntities || !instance.useMousePickEntities) return;
    //如果实体被选中的时间超过0.2S，则显示label
    var curtime = new Date().getTime(); 
    for(var i=0;i<instance.pickedEntities.length;i++){
        var entity = instance.pickedEntities[i];
        if(entity.picked_startTime){
            if(curtime-entity.picked_startTime>200){
                if(entity.otherProperty){
                    var label = entity.otherProperty.Name||entity.otherProperty.name;
                    if(label){
                        setPickeObjectLabel(instance,label,'block');
                    }
                }
            }         
        }
    }
    
    if(instance.pickedEntities.length == 0)
        setPickeObjectLabel(instance,'','none');
};

/*
 * 设置不移动鼠标pick entities
 */
vtron.comp.std.map.Cesium.prototype.setUseMousePickEntities = function(enable=true){
    this.useMousePickEntities = enable;
};

/*
 *设置图层显示阈值
 *超过某个高度，图层隐藏
 *意义：当地图缩小时，避免图层要素密集显示
 *      保持整个图层的显隐统一性
 * conf
 *    [
 *        {
 *          layerName：
 *          height：
 *        }
 *    ]
 */
vtron.comp.std.map.Cesium.prototype.setLayerDisplay = function(layerName,conf){

};

/*
 * 添加apng，test
 * return:material
 * 注：构建一个map <url,canvasobject>
 */
var addApng = function(instance,url,canvas) {
    if(!this.APNG)
        this.APNG = window["apng-js"];

    var APNGModule = this.APNG;
    var xmlhttp;
    xmlhttp=new XMLHttpRequest();
    xmlhttp.open("GET",url,true);
    xmlhttp.responseType = "arraybuffer";
    xmlhttp.onload = function(){      
        if (this.status == 200) {
            var apng = APNGModule.default(this.response);

            if (apng instanceof Error) {
              return;
            }
            apng.createImages().then(function () {
                canvas.width = apng.width;
                canvas.height = apng.height;

                apng.getPlayer(canvas.getContext('2d')).then(function (p) {
                    player = p;
                    player.playbackRate = 1.0;
                    var em = player.emit;
                    player.emit = function (event) {
                        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                            args[_key - 1] = arguments[_key];
                        }
                        em.call.apply(em, [player, event].concat(args));
                    };
                    player.play();
                });
            });
        }
    }
    xmlhttp.send();
};

var testpromise = function(instance,url,canvas) {
    var promise = new Promise(function(resolve,reject){
        if(!instance.APNG)
        instance.APNG = window["apng-js"];

        var APNGModule = instance.APNG;
        var xmlhttp;
        xmlhttp=new XMLHttpRequest();
        xmlhttp.open("GET",url,true);
        xmlhttp.responseType = "arraybuffer";
        xmlhttp.onload = function(){      
            if (this.status == 200) {
                var apng = APNGModule.default(this.response);

                if (apng instanceof Error) {
                   reject('error');
                   return;
                }
                apng.createImages().then(function () {
                    canvas.width = apng.width;
                    canvas.height = apng.height;

                    apng.getPlayer(canvas.getContext('2d')).then(function (p) {
                        player = p;
                        player.playbackRate = 1.0;
                        var em = player.emit;
                        player.emit = function (event) {
                            for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                                args[_key - 1] = arguments[_key];
                            }
                            em.call.apply(em, [player, event].concat(args));
                        };
                        player.play();
                    });

                    resolve(canvas)
                });
            }
        }
        xmlhttp.send();
    });
    return promise;
};

/*
 * 在地图上的某个位置添加一个APNG动画
 * dataInfor[{
 *     
 *         lon:
 *         lat:
 *         url:
 *         imageType:'apng'
 *         width:  //米
 *         height: //米
 *      }
 * ]
 */
vtron.comp.std.map.Cesium.prototype.addEffectElement = function(layerName,dataInfo){
    if(!this._viewer) return;
    if(!layerName) layerName = 'tempLayer';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        //supportSearch && this.searchLayerArray.push(layerName);
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
    }

    if(!dataInfo)  return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    var instance = this;
    dataInfo.forEach((data) => {
        //计算width,height大概对应的经纬度
        //经纬度转wm
        var wm = this.wgs84ToMercator({x:data.lon,y:data.lat});
        //计算envelope
        var minx = wm.x-data.width/2.0;
        var maxx = wm.x+data.width/2.0;
        var miny = wm.y-data.height/2.0;
        var maxy = wm.y+data.height/2.0;
        var envelope = this.mercatorToWgs84BB({north:maxy,east:maxx,south:miny,west:minx});

        var minLon = envelope.west;
        var maxLon = envelope.east;
        var minLat = envelope.south;
        var maxLat = envelope.north;

        var canvasobj = this.mapApngMaterial.get(data.url);
        if(!canvasobj){
            canvasobj = document.createElement('canvas');
            //this.mapApngMaterial.set(data.url,canvasobj);

            //test
            var instance = this;
            testpromise(instance,data.url,canvasobj).then(function(canvas){
                instance.mapApngMaterial.set(data.url,canvasobj);
                var apngpolygon = datasource.entities.add({
                    id:data.id,               
                    polygon : {
                        hierarchy : {
                             positions : Cesium.Cartesian3.fromDegreesArray([minLon,maxLat,
                                                                maxLon,maxLat,
                                                                maxLon,minLat,
                                                                minLon,minLat])
                        },
                        material:new Cesium.ImageMaterialProperty({
                            image:canvas, 
                            transparent:true
                        }),
                    },
                });
            },function(err){
                console.log(err);
            });
        }
        else{
            var apngpolygon = datasource.entities.add({
                    id:data.id,               
                    polygon : {
                        hierarchy : {
                             positions : Cesium.Cartesian3.fromDegreesArray([minLon,maxLat,
                                                                maxLon,maxLat,
                                                                maxLon,minLat,
                                                                minLon,minLat])
                        },
                        material:new Cesium.ImageMaterialProperty({
                            image:canvasobj, 
                            transparent:true
                        }),
                    },
               });
        } 
      
    })    
};

/*
 * path tracking:物体按照预设的路径，运动.
 * layerName: 图层名
 * dataInfo: [
 *      {
 *            id:  'pathtracking-1',
 *            image:"./car.png",// './car.gltf'
 *            path:[
 *              {time:,lon:,lat:,alt:}, //位置点的时间，纬度，高度
 *              {time,lon,lat,alt}
 *            ], 
 *            playTime: 10   //轨迹回放时，播放的时间 单位s
 *            color:
 *      }
 * ]
 * 逻辑： 1.在某空图层中添加(addPathTrackingElement)一个轨迹--->播放轨迹playPathTracking--->暂停轨迹pausePathTracking
 *        2.当轨迹播放结束以后，重播该轨迹playPathTracking
 *        3.显示隐藏删除操作参考showelement、hideelement、deleteelement
 * 注意：目前只支持一条轨迹的回放！！！
 */
vtron.comp.std.map.Cesium.prototype.addPathTrackingElement = function(layerName,dataInfo=[]){
    if(!this._viewer) return;
    var datasource = this.getDataSourceByName(layerName);//PathTrackingLayer
    if(!datasource) {
        datasource = new Cesium.CustomDataSource(layerName);
        this._viewer.dataSources.add(datasource);
        this._pathTrackingLayer_dataSource.push(datasource);
    }

    if(!dataInfo)  return;
    if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
    var instance = this;
    dataInfo.forEach((data) => {
        if(data.id){
            var bexistEntity = datasource.entities.getById(data.id);
            if(!bexistEntity){//如果存在该entity，则不做处理
                var playTime = data.playTime;
                var s = new Date();
                this.pathTracking_startTime = s;//如果多条轨迹回放，需要统一计算PathTracking_startTime
                var start = Cesium.JulianDate.fromDate(s);
                var stop = Cesium.JulianDate.addSeconds(start, playTime , new Cesium.JulianDate());

                this._viewer.clock.startTime = start.clone();
                this._viewer.clock.stopTime = stop.clone();
                this._viewer.clock.currentTime = start.clone();
                this._viewer.clock.clockRange = Cesium.ClockRange.CLAMPED; //LOOP_STOP
                //this._viewer.clock.multiplier = 1;

                //计算总时长
                var actualDurTime = data.path[data.path.length-1].time - data.path[0].time;
                var positionProperty = new Cesium.SampledPositionProperty();
                var positions = [];
                for (var i = 0; i < data.path.length; i++) {
                    var t = (data.path[i].time - data.path[0].time)/actualDurTime*playTime;
                    var time = Cesium.JulianDate.addSeconds(start,t, new Cesium.JulianDate());
                    var position = Cesium.Cartesian3.fromDegrees(data.path[i].lon, data.path[i].lat, data.path[i].alt);
                    positionProperty.addSample(time, position);
                    positions.push(position);
                    datasource.entities.add({
                        id: data.id+'.tmpPosition.'+i,
                        position : position,
                        point : {
                            pixelSize : 0,
                        }
                    });
                }

                //Actually create the entity
                var entity = undefined;
                if(data.image.indexOf("gltf")>0){
                    //路径本身：但没有线显示
                    entity = datasource.entities.add({
                        id: data.id,
                        availability : new Cesium.TimeIntervalCollection([new Cesium.TimeInterval({
                            start : start,
                            stop : stop
                        })]),
                        model:{
                            uri:data.image,
                            minimumPixelSize:64
                        },
                        position : positionProperty,
                        orientation : new Cesium.VelocityOrientationProperty(positionProperty),
                        path : {
                            resolution : 1,
                            material : new Cesium.PolylineGlowMaterialProperty({
                               glowPower : 0.1,
                               color : Cesium.Color.fromCssColorString(data.color)||Cesium.Color.YELLOW
                            }),
                            //material : Cesium.Color.fromCssColorString("rgba(255, 0, 0, 0)"),
                            width : data.width||10,
                            //zIndex: 1,
                        },
                        /*polyline : {
                            positions : positions,//Cesium.Cartesian3.fromDegreesArrayHeights([118, 32, 25000,119, 32, 25000]),
                            //positions : Cesium.Cartesian3.fromDegreesArrayHeights([118.12, 30.0, 0,118.15, 30.0, 0,118.15,29.95,0]),
                            width : data.width||10,
                            material : Cesium.Color.fromCssColorString(data.color),
                            zIndex: 2,
                        }*/
                    });
                    entity.dyPositions = [];

                    // 属性回调会影响地图场景性能，有待检查
                    //entity.polyline.positions = new Cesium.CallbackProperty(() => {return entity.dyPositions}, false);
                    
                    //路径的线
                    // var baseline = datasource.entities.add({
                    //     name : "1",
                    //     polyline : {
                    //         positions : Cesium.Cartesian3.fromDegreesArrayHeights([118.12, 30.0, 0,118.15, 30.0, 0,119,30,0]),
                    //         width : data.width||10,
                    //         material : Cesium.Color.RED,
                    //     }
                    // });

                    //当前的轨迹
                    // var curMovementline = datasource.entities.add({
                    //     name:"2",
                    //     polyline : {
                            
                    //         positions : Cesium.Cartesian3.fromDegreesArrayHeights([119.12, 30.0, 1000,118.15, 30.0, 100]),
                    //         //positions : [],
                    //         //width : data.width||10,
                    //         //material : Cesium.Color.BLUE,
                    //     }
                    // });
                    //curMovementline.polyline.positions = new Cesium.CallbackProperty(() => {return entity.dyPositions}, false);
                }
                else{
                    entity = datasource.entities.add({
                        id:data.id,
                        availability : new Cesium.TimeIntervalCollection([new Cesium.TimeInterval({
                            start : start,
                            stop : stop
                        })]),
                        position : positionProperty,
                        orientation : new Cesium.VelocityOrientationProperty(positionProperty),
                        billboard: {
                           image:data.image,//"/test-map-engine/image/alert.png",
                           scale:0.5,
                           verticalOrigin: Cesium.VerticalOrigin.BOTTOM
                        },
                        //Show the path as a pink line sampled in 1 second increments.
                        path : {
                            resolution : 1,
                            material : new Cesium.PolylineGlowMaterialProperty({
                                glowPower : 0.1,
                                color : Cesium.Color.fromCssColorString(data.color)||Cesium.Color.YELLOW
                            }),
                            width : data.width
                        },
                    });
                }
                entity.pathTracking_startTime = s;//每条轨迹都有一个开始播放的时间
                entity.dyPositions = [];//记录该路径中图片运动的实时点序列
                entity.animate = true;
            }   
        }
    });
    
    this._viewer.trackedEntity = undefined;
    datasource.pathTrackingLayer = true;//标记该图层是轨迹回放图层
    this._viewer.clockViewModel.shouldAnimate = false;
};

/*
 * 播放轨迹（历史轨迹和实时轨迹路径跟踪）:只实现单个历史轨迹，实时轨迹则可以多个
 * layerName:图层名
 * dataInfo:[    //如果要实现多个历史轨迹的控制时，需要设置
 * id:,id:]
 * color:实时轨迹的颜色
 * width：实时轨迹的宽度
 */
vtron.comp.std.map.Cesium.prototype.playPathTracking = function(layerName,dataInfo=[],color='rgba(255,0,0,1)',width=5){
    if(this._viewer){
        var datasource = this.getDataSourceByName(layerName);
        if(!datasource) return;
        if(datasource.pathTrackingLayer==undefined && datasource.animate==undefined) return;
        if(datasource.pathTrackingLayer){ 
            //历史轨迹图层的时间控制
            this._viewer.clockViewModel.shouldAnimate = true;
            if(Cesium.JulianDate.compare(this._viewer.clock.tick(), this._viewer.clock.stopTime)>=0){
                this._viewer.clock.currentTime = this.pathTracking_startTime;
            } 
        }
        else if(datasource.animate){
            //实时轨迹比如实时gps
            //遍历到某个要素
            if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
            dataInfo.forEach((data) => {
                var entity = datasource.entities.getById(data);
                var lineId = data +'-realTime_line';
                var entityLine = datasource.entities.getById(lineId);

                if(entity&&entityLine==undefined){
                    //存在gps点，但没有实时轨迹，则创建轨迹对象
                    var realTime_line = datasource.entities.add({
                        id : data +'-realTime_line',
                        polyline : {
                            positions : [],// Cesium.Cartesian3.fromDegreesArrayHeights(entity.pathTrack),
                            width : width||5,
                            material : Cesium.Color.fromCssColorString(color)||Cesium.Color.RED
                            //clampToGround : true
                        }
                    });
                    realTime_line.polyline.positions = new Cesium.CallbackProperty(() => {
                        if(entity.pathRender.length>=6)
                            return Cesium.Cartesian3.fromDegreesArrayHeights(entity.pathRender)
                        else
                            return [];
                    }, false);

                    //当前entity的pathTrackde长度
                    //gps当前点正在朝最后一个点运动
                    entity.playRealTimeTrack = true;
                }
            });
        }
    }
}

/*
 * stop:暂停历史轨迹；或者暂停实时轨迹
 * layerName:图层名
 * dataInfo:[
 * id:,id:]
 */
vtron.comp.std.map.Cesium.prototype.stopPathTracking = function(layerName,dataInfo=[]){
    if(this._viewer){
        var datasource = this.getDataSourceByName(layerName);
        if(!datasource) return;
        if(datasource.pathTrackingLayer==undefined&&datasource.animate==undefined) return;
        if(datasource.pathTrackingLayer){ 
            //lishi l
            this._viewer.clockViewModel.shouldAnimate = false;
        }
        else if(datasource.animate != undefined){
            //隐藏实时轨迹，后续考虑
            if(!(dataInfo instanceof Array)) dataInfo = [dataInfo];
            dataInfo.forEach((data) => {
                var lineId = data +'-realTime_line';
                datasource.entities.removeById(lineId);
                var entity = datasource.entities.getById(data);
                entity.pathRender = [];
                entity.pathTrack = [];
                entity.playRealTimeTrack = false;
            });
        }
    }
};

/*
 * 重头播放轨迹
 * layerName:图层名
 * dataInfo:[
 * id:,id:]
 */
vtron.comp.std.map.Cesium.prototype.replayPathTracking = function(layerName,dataInfo=[]){
    if(this._viewer){
        var datasource = this.getDataSourceByName(layerName);
        if(!datasource) return;
        if(!datasource.pathTrackingLayer) return;
        this._viewer.clock.currentTime = this.pathTracking_startTime;
        this.playPathTracking(layerName,dataInfo);
    }
};
/*
 * 获取所有的图层
 */
vtron.comp.std.map.Cesium.prototype.getLayers = function(){
    if(!this._viewer) return null;
    var layers = []
    for(let dataSource of this._viewer.dataSources._dataSources) {
        layers.push(dataSource);
    }
    return layers;
};

/*
 * searchbyturf方法的封装性不好！
 * 空间搜索：通过几何体的方式，从图层中查找 //下个版本完成该函数selectElementByShape
 * layers： [layerName,layerName...]
 * shape: geojson的描述，目前只支持面,圆
 * 注：普通的面的表示如下：
 * shape:
 * {
 *    "type":"Polygon",
 *    "coordinates":[
 *        [[120.1,30.2],[120.2,30.2],[120.2,30.1],[120.1,30.1],[120.1,30.2]]
 *    ]
 * }
 *
 * 圆的shape：
 * {
 *     "type":"Circle",
 *     "centre":[120.1,30.2],
 *     "radius":500 //米
 * }
 *
 * 返回：
 * [
 *   {
 *      layerName: 'name',
 *      elements:[id,id,id]
 *   },
 *   {
 *      layerName: 'name',
 *      elements:[id,id,id]
 *   }
 * ]
 */
vtron.comp.std.map.Cesium.prototype.selectElementByShape = function(layers,shape){
    return;
    /*if(!this._viewer) return null;
    var retValue = []
    for(var layerObject of layers) {
        var oneLayerValue = {};
        oneLayerValue.name = layerObject.name;
        var selectedEle = [];

    }
    return retValue;*/
};

/*
 * 定位到某些element，相当于当这些elements在屏幕显示范围内
 * layerName:图层名
 * fids：要素id数组
 */
vtron.comp.std.map.Cesium.prototype.zoomToElement = function(layerName,fids){
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) return;
    if(!fids||!fids.length) return;
    if(!(fids instanceof Array)) fids = [fids];

    if(!datasource.pathTrackingLayer){
        //普通图层：例如gps，等等
        var entities = new Cesium.EntityCollection();
        fids.forEach(id => {
          var entity = datasource.entities.getById(id);
          if(entity){
            entities.add(entity);
          }
        });
        this._viewer.zoomTo(entities);
    }
    else{
        //历史轨迹图层中只有一条历史轨迹，每条轨迹（每个id）可能对应若干个辅助定位的entity
        this._viewer.zoomTo(datasource.entities);//cesium集成的方法，不能把entity缩放到都在屏幕范围内，比如历史轨迹
    }
};

/*
*  设置要素的跟踪 ：要素位置变化时，始终在屏幕中间限制
*  layername：图层名
*  fid 
*  swithch: true：开启跟踪
*           false:关闭跟踪
 */
vtron.comp.std.map.Cesium.prototype.trackElement = function(layerName, fid,track=false) {
    //查找到该点，并设置点的tracked属性
    if(!layerName) return '未设置图层名！';
    var datasource = this.getDataSourceByName(layerName);
    if(!datasource) {
        return '图层不存在！';
    }
    
    if(!fid) return;
    var entity = datasource.entities.getById(fid);
    if(entity){
        if(track){
            this._viewer.trackedEntity = entity;
        }
        else{
            this._viewer.trackedEntity = null;
        }
    }
};
